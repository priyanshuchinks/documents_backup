USE [SAPBodsPi_ProfData_Prod]
GO

/****** Object:  Table [SSISPi_FIN_Transformed_Data_Dev].[FIN_AUDIT_ERRORLOG]    Script Date: 17/06/2021 3:23:02 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [SSISPi_FIN_Transformed_Data_Dev].[FIN_AUDIT_ERRORLOG](
	[ERROR_ID] [int] IDENTITY(1,1) NOT NULL,
	[BATCH_ID] [bigint] NULL,
	[PACKAGE_NAME] [nvarchar](255) NULL,
	[EXTRACT_NAME] [nvarchar](255) NULL,
	[ALTERNATE_KEY] [nvarchar](255) NULL,
	[ERROR_COMPONENT_NAME] [nvarchar](255) NULL,
	[ERROR_COLUMN_NAME] [nvarchar](255) NULL,
	[ERROR_DESCRIPTION] [nvarchar](max) NULL,
	[ERROR_TYPE] [nvarchar](255) NULL,
	[ERROR_LOGGING_TIME] [datetime] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO


