USE [SAPBodsPi_ProfData_Prod]
GO

/****** Object:  StoredProcedure [SSISPi_FIN_Transformed_Data].[WD_STG_CUSTOM_VIEW_REPORT_2]    Script Date: 17/06/2021 3:14:53 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO





CREATE PROCEDURE [SSISPi_FIN_Transformed_Data].[WD_STG_CUSTOM_VIEW_REPORT_2] @wd_extract_name NVARCHAR(200) = NULL
AS
DECLARE @TABLE_NAME NVARCHAR(MAX) = '';
DECLARE @a VARCHAR(250);
DECLARE @b VARCHAR(250);
DECLARE @cnt INT;
DECLARE @counter INT = 1;
DECLARE @vCreate_Sql NVARCHAR(max) = ''


DECLARE cursor_temp CURSOR
FOR
SELECT STAGING_TABLE
	,ALTERNATE_KEY_REPORTING
FROM SSISPi_FIN_Transformed_Data.FIN_EXTRACT_CONFIG
WHERE IS_ACTIVE = 1
	AND EXTRACT_NAME = ISNULL(@wd_extract_name, EXTRACT_NAME);

SELECT @cnt = count(*)
FROM SSISPi_FIN_Transformed_Data.FIN_EXTRACT_CONFIG
WHERE IS_ACTIVE = 1
	AND EXTRACT_NAME = ISNULL(@wd_extract_name, EXTRACT_NAME);

OPEN cursor_temp;

FETCH NEXT
FROM cursor_temp
INTO @a
	,@b;

WHILE (@counter < @cnt)
BEGIN
	SET @vCreate_Sql = @vCreate_Sql + 'SELECT T4.SUBJECT_AREA AS SUBJECT_AREA, NULL AS SOURCE_SYSTEM, T3.EXTRACT_NAME as EXTRACT_NAME, T3.ALTERNATE_KEY_COLUMN AS ALTERNATE_KEY, T1.ALTERNATE_KEY AS ALTERNATE_KEY_VALUE, ''Data available in Workday but not loaded in Staging'' AS ERROR_DESCRIPTION, T1.BATCH_ID, T1.LOAD_DATETIME
            FROM (select * from SSISPi_FIN_Transformed_Data.WD_EXTRACT_' + @a + ') T1
            LEFT JOIN (select a.*,' + @b + ' AS AK, b.EXTRACT_NAME from SSISPi_FIN_Transformed_Data.' + @a + ' a 
			inner join SSISPi_FIN_Transformed_Data.FIN_EXTRACT_CONFIG b
			on ''' + @a + ''' = b.STAGING_TABLE) T2
               ON T1.ALTERNATE_KEY = T2.AK
			INNER JOIN (select * from SSISPi_FIN_Transformed_Data.FIN_EXTRACT_CONFIG) T3
				ON LTRIM(RTRIM(''' + @a + ''')) = T3.STAGING_TABLE
			LEFT JOIN (SELECT DISTINCT REPLACE(REPLACE(SUBJECT_AREA,''-AU'',''''),''-VN'','''') AS SUBJECT_AREA, REPLACE(REPLACE(EXTRACT_NAME,''_AU'',''''),''_VN'','''') AS EXTRACT_NAME FROM SSISPi_FIN_Transformed_Data.FIN_AUDIT_MAP_EXTRACT_AK) T4
				ON T3.EXTRACT_NAME = T4.EXTRACT_NAME
            WHERE T2.ALTERNATE_KEY is NULL';
	SET @vCreate_Sql = @vCreate_Sql + ' union ';

	FETCH NEXT
	FROM cursor_temp
	INTO @a
		,@b;

	SET @counter = @counter + 1;
END

BEGIN
	SET @vCreate_Sql = @vCreate_Sql + 'SELECT T4.SUBJECT_AREA AS SUBJECT_AREA, NULL AS SOURCE_SYSTEM, T3.EXTRACT_NAME as EXTRACT_NAME, T3.ALTERNATE_KEY_COLUMN AS ALTERNATE_KEY, T1.ALTERNATE_KEY AS ALTERNATE_KEY_VALUE, ''Data available in Workday but not loaded in Staging'' AS ERROR_DESCRIPTION, T1.BATCH_ID, T1.LOAD_DATETIME
            FROM (select * from SSISPi_FIN_Transformed_Data.WD_EXTRACT_' + @a + ') T1
            LEFT JOIN (select a.*,' + @b + ' AS AK, b.EXTRACT_NAME from SSISPi_FIN_Transformed_Data.' + @a + ' a 
			inner join SSISPi_FIN_Transformed_Data.FIN_EXTRACT_CONFIG b
			on ''' + @a + ''' = b.STAGING_TABLE) T2
               ON T1.ALTERNATE_KEY = T2.AK
			INNER JOIN (select * from SSISPi_FIN_Transformed_Data.FIN_EXTRACT_CONFIG) T3
				ON LTRIM(RTRIM(''' + @a + ''')) = T3.STAGING_TABLE
			LEFT JOIN (SELECT DISTINCT REPLACE(REPLACE(SUBJECT_AREA,''-AU'',''''),''-VN'','''') AS SUBJECT_AREA, REPLACE(REPLACE(EXTRACT_NAME,''_AU'',''''),''_VN'','''') AS EXTRACT_NAME FROM SSISPi_FIN_Transformed_Data.FIN_AUDIT_MAP_EXTRACT_AK) T4
				ON T3.EXTRACT_NAME = T4.EXTRACT_NAME
            WHERE T2.ALTERNATE_KEY is NULL';
END

CLOSE cursor_temp;

DEALLOCATE cursor_temp;

INSERT INTO SSISPi_FIN_Transformed_Data.FIN_DATA_CONVERSION_CUSTOM_SOLUTION_REPORT_2
EXECUTE (@vCreate_Sql);
GO


