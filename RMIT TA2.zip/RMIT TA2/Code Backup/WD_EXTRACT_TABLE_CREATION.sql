USE [SAPBodsPi_ProfData_Prod]
GO

/****** Object:  StoredProcedure [SSISPi_FIN_Transformed_Data].[WD_EXTRACT_TABLE_CREATION]    Script Date: 17/06/2021 3:18:17 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO






CREATE PROCEDURE [SSISPi_FIN_Transformed_Data].[WD_EXTRACT_TABLE_CREATION] @ip_extract_name NVARCHAR(200)
AS
BEGIN
	DECLARE @DATABASE NVARCHAR(250) = 'SAPBodsPi_ProfData_Prod'
	DECLARE @TABLE_SCHEMA NVARCHAR(250) = 'SSISPi_FIN_Transformed_Data'
	DECLARE @EXTRACT NVARCHAR(250) = @ip_extract_name
	DECLARE @EXTRACT_FILE NVARCHAR(250)
	DECLARE @TABLE_NAME VARCHAR(250)
	DECLARE @a VARCHAR(250)
	DECLARE @b VARCHAR(250)
	DECLARE @c VARCHAR(250)
	DECLARE @d VARCHAR(250)
	DECLARE @e VARCHAR(250)
	DECLARE @f VARCHAR(250)
	DECLARE @SQL_DROP_TABLE NVARCHAR(max) = ''
	DECLARE @vCreate_Sql NVARCHAR(max) = ''
	
	EXECUTE ('USE SAPBodsPi_ProfData_Prod');

	SELECT @TABLE_NAME = STAGING_TABLE,
	@EXTRACT_FILE = WD_EXTRACT_FILE
	FROM SSISPi_FIN_Transformed_Data.FIN_EXTRACT_CONFIG
		WHERE EXTRACT_NAME = @EXTRACT
		and IS_ACTIVE = 1
		AND EXTRACT_NAME = ISNULL(@EXTRACT, EXTRACT_NAME);

	------ Test that the entry in config table exists ------
	IF (
			@TABLE_NAME = ''
			OR @TABLE_NAME IS NULL
			)
	BEGIN
		RAISERROR (
				'The extract entry does not exist in the config table'
				,16
				,1
				)

		RETURN
	END
	
	------ Dynamic Table Creation ------
	BEGIN
		IF EXISTS (
			Select *
			FROM INFORMATION_SCHEMA.COLUMNS
			WHERE TABLE_CATALOG = 'SAPBodsPi_ProfData_Prod'
			AND TABLE_SCHEMA = 'SSISPi_FIN_Transformed_Data'
			AND TABLE_NAME = 'WD_EXTRACT_BI_' + @TABLE_NAME + ''
			)
		BEGIN
			SET @SQL_DROP_TABLE = 'drop table SSISPi_FIN_Transformed_Data.WD_EXTRACT_BI_' + @TABLE_NAME + '';
			EXEC (@SQL_DROP_TABLE);
		END
		/*
		BEGIN
		SET @vCreate_Sql = 'CREATE TABLE SSISPi_FIN_Transformed_Data.WD_EXTRACT_' + @TABLE_NAME + '(';

		DECLARE @cnt INT;
		DECLARE @counter INT = 1;

		DECLARE cursor_temp CURSOR
		FOR
		SELECT COLUMN_NAME
			,DATA_TYPE
			,(CHARACTER_MAXIMUM_LENGTH) AS CHARACTER_MAXIMUM_LENGTH
			,NUMERIC_PRECISION
			,NUMERIC_SCALE
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_CATALOG = 'SAPBodsPi_ProfData_Prod'
			AND TABLE_SCHEMA = 'SSISPi_FIN_Transformed_Data'
			AND TABLE_NAME = @TABLE_NAME
			AND COLUMN_NAME NOT IN (
				'SOURCE_SYSTEM'
				,'LOAD_DATETIME'
				,'BATCH_ID'
				,'PACKAGE_NAME'
				,'ALTERNATE_KEY'
				)
		ORDER BY ORDINAL_POSITION;

		SELECT @cnt = count(*)
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_CATALOG = 'SAPBodsPi_ProfData_Prod'
			AND TABLE_SCHEMA = 'SSISPi_FIN_Transformed_Data'
			AND TABLE_NAME = @TABLE_NAME
			AND COLUMN_NAME NOT IN (
				'SOURCE_SYSTEM'
				,'LOAD_DATETIME'
				,'BATCH_ID'
				,'PACKAGE_NAME'
				,'ALTERNATE_KEY'
				);

		OPEN cursor_temp;

		FETCH NEXT
		FROM cursor_temp
		INTO @a
			,@b
			,@c
			,@d
			,@e;

		WHILE (@counter <= @cnt)
		BEGIN
				SET @b = 'nvarchar'
				SET @c = 500
				IF @a = 'PERCENT'
				BEGIN
				SET @vCreate_Sql = @vCreate_Sql + ' [' + @a + '] ' + @b + '(' + @c + ')';
				END
				ELSE
				BEGIN
				SET @vCreate_Sql = @vCreate_Sql + ' ' + @a + ' ' + @b + '(' + @c + ')';
				END
				SET @vCreate_Sql = @vCreate_Sql + ',';
		
			FETCH NEXT
			FROM cursor_temp
			INTO @a
				,@b
				,@c
				,@d
				,@e;

			SET @counter = @counter + 1;
		END

		BEGIN
			SET @vCreate_Sql = @vCreate_Sql + ' BATCH_ID int NULL, LOAD_DATETIME datetime NOT NULL';
		END

		CLOSE cursor_temp;

		DEALLOCATE cursor_temp;

		SET @vCreate_Sql = @vCreate_Sql + ')';

		EXECUTE (@vCreate_Sql);
		END
		*/
	END

	BEGIN
		SELECT 'SSISPi_FIN_Transformed_Data.WD_EXTRACT_BI_' + @TABLE_NAME + '' AS TABLE_NAME
			,@EXTRACT_FILE AS FILE_NAME
	END	
END
GO


