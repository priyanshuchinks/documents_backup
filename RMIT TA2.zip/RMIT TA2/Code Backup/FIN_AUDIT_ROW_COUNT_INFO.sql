USE [SAPBodsPi_ProfData_Prod]
GO

/****** Object:  Table [SSISPi_FIN_Transformed_Data_Dev].[FIN_AUDIT_ROW_COUNT_INFO]    Script Date: 17/06/2021 3:23:36 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [SSISPi_FIN_Transformed_Data_Dev].[FIN_AUDIT_ROW_COUNT_INFO](
	[BATCH_ID] [bigint] NULL,
	[INPUT_ROW_COUNT] [bigint] NULL,
	[INSERT_ROW_COUNT] [bigint] NULL,
	[UPDATE_ROW_COUNT] [bigint] NULL,
	[DELETE_ROW_COUNT] [bigint] NULL,
	[FAILED_ROW_COUNT] [bigint] NULL
) ON [PRIMARY]
GO


