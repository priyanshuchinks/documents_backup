USE [SAPBodsPi_ProfData_Prod]
GO

/****** Object:  StoredProcedure [SSISPi_HR_Transformed_Data].[FIND_TABLE_NAMES]    Script Date: 17/06/2021 3:19:08 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO






CREATE PROCEDURE [SSISPi_HR_Transformed_Data].[FIND_TABLE_NAMES] @RULE_ID NVARCHAR(200)
AS

DECLARE @name NVARCHAR(max);
DECLARE @tbl_name NVARCHAR(max);
DECLARE @RULE_ID1 NVARCHAR(250);
SET @RULE_ID1 = @RULE_ID;
DECLARE @a TABLE (pos INT)
DECLARE @pos INT
DECLARE @oldpos INT
DECLARE @pos_value VARCHAR(250);
DECLARE @counter1 INT = 1;
DECLARE @vCreate_Sql1 NVARCHAR(max) = ''


SELECT @name = SQL_QRY1_VAL_BKP,
@tbl_name = tbl_name
FROM SSISPi_HR_Transformed_Data.HR_QAQC_RULES_BKP1012
WHERE DESCR LIKE 'CC[_]%' AND SQL_QRY1_VAL_BKP IS NOT NULL
AND RULE_ID = @RULE_ID1;


SELECT @oldpos = 0

SELECT @pos = patindex('%SSISPi_HR_Transformed_Data%', @name)

WHILE @pos > 0
	AND @oldpos <> @pos
BEGIN
	INSERT INTO @a
	VALUES (@pos)

	SELECT @oldpos = @pos

	SELECT @pos = patindex('%SSISPi_HR_Transformed_Data%', Substring(@name, @pos + 1, len(@name))) + @pos
END

--Select * from @a
--select @name

DECLARE @cnt INT;

DECLARE cursor_temp1 CURSOR
FOR
SELECT *
FROM @a;

SELECT @cnt = count(*)
FROM @a;

OPEN cursor_temp1;

FETCH NEXT
FROM cursor_temp1
INTO @pos_value;

WHILE (@counter1 < @cnt)
BEGIN
	BEGIN
		SET @vCreate_Sql1 = @vCreate_Sql1 + 'SELECT TBL_NAME, SUBSTRING(SQL_QRY1_VAL_BKP,' + @pos_value + ',
CHARINDEX('' '',SUBSTRING(SQL_QRY1_VAL_BKP,' + @pos_value + ',LEN(SQL_QRY1_VAL_BKP)))) AS SRC_TBLS
FROM SSISPi_HR_Transformed_Data.HR_QAQC_RULES_BKP1012
WHERE DESCR LIKE ''CC[_]%'' AND SQL_QRY1_VAL_BKP IS NOT NULL AND RULE_ID = '+@RULE_ID1+'';
		SET @vCreate_Sql1 = @vCreate_Sql1 + ' union ';
	END

	FETCH NEXT
	FROM cursor_temp1
	INTO @pos_value;

	SET @counter1 = @counter1 + 1;
END

BEGIN
	SET @vCreate_Sql1 = @vCreate_Sql1 + 'SELECT TBL_NAME, SUBSTRING(SQL_QRY1_VAL_BKP,' + @pos_value + ',
CHARINDEX('' '',SUBSTRING(SQL_QRY1_VAL_BKP,' + @pos_value + ',LEN(SQL_QRY1_VAL_BKP)))) AS SRC_TBLS
FROM SSISPi_HR_Transformed_Data.HR_QAQC_RULES_BKP1012
WHERE DESCR LIKE ''CC[_]%'' AND SQL_QRY1_VAL_BKP IS NOT NULL AND RULE_ID = '+@RULE_ID1+'';
END

CLOSE cursor_temp1;

DEALLOCATE cursor_temp1;


INSERT INTO SSISPi_HR_Transformed_Data.HR_SOURCE_TABLES
EXEC (@vCreate_Sql1);


GO


