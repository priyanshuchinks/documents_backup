USE [SAPBodsPi_ProfData_Prod]
GO

/****** Object:  StoredProcedure [SSISPi_FIN_Transformed_Data].[WD_STG_CUSTOM_VIEW_REPORT_3]    Script Date: 17/06/2021 3:15:12 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE PROCEDURE [SSISPi_FIN_Transformed_Data].[WD_STG_CUSTOM_VIEW_REPORT_3] @wd_extract_name NVARCHAR(200) = NULL
AS
DECLARE @vCreate_Sql1 NVARCHAR(max) = ''
DECLARE @vCreate_Sql2 NVARCHAR(max) = ''
DECLARE @vCreate_Sql3 NVARCHAR(max) = ''
DECLARE @vCreate_Sql4 NVARCHAR(max) = ''
DECLARE @a VARCHAR(250);
DECLARE @b VARCHAR(250);
DECLARE @c VARCHAR(250);
DECLARE @d VARCHAR(250);
DECLARE @e VARCHAR(250);
DECLARE @f VARCHAR(250);
DECLARE @g VARCHAR(250);
DECLARE @cnt INT;
DECLARE @counter1 INT = 1;
DECLARE @counter2 INT = 1;
DECLARE @counter3 INT = 1;
DECLARE @counter4 INT = 1;
DECLARE @cnt_cols INT;
DECLARE @sql2 NVARCHAR(max) = ''
DECLARE @STG_VALUE NVARCHAR(250)
DECLARE @WD_VALUE NVARCHAR(250)
DECLARE @COL_NAME NVARCHAR(250)
DECLARE @E_NAME NVARCHAR(250)

---1
DECLARE cursor_temp1 CURSOR
FOR
SELECT AK.STAGING_TABLE
	,COL.COLUMN_NAME
	,COL.DATA_TYPE
	,COL.NUMERIC_PRECISION
	,COL.NUMERIC_SCALE
	,AK.ALTERNATE_KEY_REPORTING
	,AK.EXTRACT_NAME
FROM SSISPi_FIN_Transformed_Data.FIN_EXTRACT_CONFIG AK
INNER JOIN INFORMATION_SCHEMA.COLUMNS COL ON AK.STAGING_TABLE = COL.TABLE_NAME
	AND TABLE_SCHEMA = 'SSISPi_FIN_Transformed_Data'
	AND AK.IS_ACTIVE = 1
	AND COLUMN_NAME NOT IN (
		'SOURCE_SYSTEM'
		,'LOAD_DATETIME'
		,'BATCH_ID'
		,'PACKAGE_NAME'
		,'ALTERNATE_KEY'
		)
	AND DATA_TYPE = 'nvarchar'
	AND EXTRACT_NAME = ISNULL(@wd_extract_name, EXTRACT_NAME);

SELECT @cnt = count(*)
FROM SSISPi_FIN_Transformed_Data.FIN_EXTRACT_CONFIG AK
INNER JOIN INFORMATION_SCHEMA.COLUMNS COL ON AK.STAGING_TABLE = COL.TABLE_NAME
	AND TABLE_SCHEMA = 'SSISPi_FIN_Transformed_Data'
	AND AK.IS_ACTIVE = 1
	AND COLUMN_NAME NOT IN (
		'SOURCE_SYSTEM'
		,'LOAD_DATETIME'
		,'BATCH_ID'
		,'PACKAGE_NAME'
		,'ALTERNATE_KEY'
		)
	AND DATA_TYPE = 'nvarchar'
	AND EXTRACT_NAME = ISNULL(@wd_extract_name, EXTRACT_NAME);

OPEN cursor_temp1;

FETCH NEXT
FROM cursor_temp1
INTO @a
	,@b
	,@c
	,@d
	,@e
	,@f
	,@g;

IF (@cnt != 0)
BEGIN
	WHILE (@counter1 < @cnt)
	BEGIN
		IF EXISTS (
				SELECT COLUMN_NAME
					,WD_VALUE
					,STG_VALUE
				FROM SSISPi_FIN_Transformed_Data.FIN_AUDIT_DATA_COMPARISON_CONFIG
				WHERE TEMP1 = 'REPLACE_FUNCTION'
					AND TEMP2 = 'STAGING'
					AND COLUMN_NAME = @b
					AND Extract_Name = @g
				)
		BEGIN
			SELECT @COL_NAME = COLUMN_NAME
				,@WD_VALUE = WD_VALUE
				,@STG_VALUE = STG_VALUE
			FROM SSISPi_FIN_Transformed_Data.FIN_AUDIT_DATA_COMPARISON_CONFIG
			WHERE TEMP1 = 'REPLACE_FUNCTION'
				AND TEMP2 = 'STAGING'
				AND COLUMN_NAME = @b
				AND Extract_Name = @g;

			SET @vCreate_Sql1 = @vCreate_Sql1 + 'select T3.SUBJECT_AREA AS SUBJECT_AREA, T1.SOURCE_SYSTEM AS SOURCE_SYSTEM, T1.EXTRACT_NAME as EXTRACT_NAME, T1.ALTERNATE_KEY_COLUMN AS ALTERNATE_KEY,
T1.ALTERNATE_KEY AS ALTERNATE_KEY_VALUE,
''' + @b + ''' AS COLUMN_NAME,
CONVERT(NVARCHAR(500),T1.' + @b + ') AS VALUE_IN_STAGE,
CASE WHEN CONVERT(NVARCHAR(500),T2.' + @b + ') = '''' THEN NULL ELSE CONVERT(NVARCHAR(500),T2.' + @b + ') END AS VALUE_IN_WORKDAY,
''Mismatch between WorkDay and Staging'' AS ERROR_DESCRIPTION,
T4.BATCH_ID,
T4.LOAD_DATETIME
FROM (select a.*,' + @f + ' AS AK, b.EXTRACT_NAME, b.ALTERNATE_KEY_COLUMN from SSISPi_FIN_Transformed_Data.' + @a + ' a 
			inner join SSISPi_FIN_Transformed_Data.FIN_EXTRACT_CONFIG b
			on ''' + @a + ''' = b.STAGING_TABLE) T1
            INNER JOIN SSISPi_FIN_Transformed_Data.WD_EXTRACT_' + @a + 
				' T2
               ON T1.AK = T2.ALTERNATE_KEY
			LEFT JOIN (SELECT DISTINCT REPLACE(REPLACE(SUBJECT_AREA,''-AU'',''''),''-VN'','''') AS SUBJECT_AREA, REPLACE(REPLACE(EXTRACT_NAME,''_AU'',''''),''_VN'','''') AS EXTRACT_NAME FROM SSISPi_FIN_Transformed_Data.FIN_AUDIT_MAP_EXTRACT_AK) T3
				ON T1.EXTRACT_NAME = T3.EXTRACT_NAME
			LEFT JOIN (select distinct BATCH_ID, LOAD_DATETIME from SSISPi_FIN_Transformed_Data.WD_EXTRACT_' + @a + ') T4
				ON 1 = 1
			WHERE CASE WHEN ' + @STG_VALUE + ' = ''Y'' THEN ''1'' WHEN ' + @STG_VALUE + ' = ''N'' THEN ''0'' ELSE ' + @STG_VALUE + ' END != ISNULL(T2.' + @b + ','''')';
			SET @vCreate_Sql1 = @vCreate_Sql1 + ' union ';
		END

		IF NOT EXISTS (
				SELECT COLUMN_NAME
					,WD_VALUE
					,STG_VALUE
				FROM SSISPi_FIN_Transformed_Data.FIN_AUDIT_DATA_COMPARISON_CONFIG
				WHERE TEMP1 = 'REPLACE_FUNCTION'
					AND TEMP2 = 'STAGING'
					AND COLUMN_NAME = @b
					AND Extract_Name = @g
				)
			AND NOT EXISTS (
				SELECT COLUMN_NAME
					,WD_VALUE
					,STG_VALUE
				FROM SSISPi_FIN_Transformed_Data.FIN_AUDIT_DATA_COMPARISON_CONFIG
				WHERE TEMP1 = 'REMOVE_COLUMN'
					AND TEMP2 = 'STAGING'
					AND COLUMN_NAME = @b
					AND Extract_Name = @g
				)
		BEGIN
			SET @vCreate_Sql1 = @vCreate_Sql1 + 'select T3.SUBJECT_AREA AS SUBJECT_AREA, T1.SOURCE_SYSTEM AS SOURCE_SYSTEM, T1.EXTRACT_NAME as EXTRACT_NAME, T1.ALTERNATE_KEY_COLUMN AS ALTERNATE_KEY,
T1.ALTERNATE_KEY AS ALTERNATE_KEY_VALUE,
''' + @b + ''' AS COLUMN_NAME,
CONVERT(NVARCHAR(500),T1.' + @b + ') AS VALUE_IN_STAGE,
CASE WHEN CONVERT(NVARCHAR(500),T2.' + @b + ') = '''' THEN NULL ELSE CONVERT(NVARCHAR(500),T2.' + @b + ') END AS VALUE_IN_WORKDAY,
''Mismatch between WorkDay and Staging'' AS ERROR_DESCRIPTION,
T4.BATCH_ID,
T4.LOAD_DATETIME
FROM (select a.*,' + @f + ' AS AK, b.EXTRACT_NAME, b.ALTERNATE_KEY_COLUMN from SSISPi_FIN_Transformed_Data.' + @a + ' a 
			inner join SSISPi_FIN_Transformed_Data.FIN_EXTRACT_CONFIG b
			on ''' + @a + ''' = b.STAGING_TABLE) T1
            INNER JOIN SSISPi_FIN_Transformed_Data.WD_EXTRACT_' + @a + 
				' T2
               ON T1.AK = T2.ALTERNATE_KEY
			LEFT JOIN (SELECT DISTINCT REPLACE(REPLACE(SUBJECT_AREA,''-AU'',''''),''-VN'','''') AS SUBJECT_AREA, REPLACE(REPLACE(EXTRACT_NAME,''_AU'',''''),''_VN'','''') AS EXTRACT_NAME FROM SSISPi_FIN_Transformed_Data.FIN_AUDIT_MAP_EXTRACT_AK) T3
				ON T1.EXTRACT_NAME = T3.EXTRACT_NAME
			LEFT JOIN (select distinct BATCH_ID, LOAD_DATETIME from SSISPi_FIN_Transformed_Data.WD_EXTRACT_' + @a + ') T4
				ON 1 = 1
			WHERE CASE WHEN T1.' + @b + ' = ''Y'' THEN ''1'' WHEN T1.' + @b + ' = ''N'' THEN ''0'' ELSE ISNULL(T1.' + @b + ','''') END != ISNULL(T2.' + @b + ','''')';
			SET @vCreate_Sql1 = @vCreate_Sql1 + ' union ';
		END

		FETCH NEXT
		FROM cursor_temp1
		INTO @a
			,@b
			,@c
			,@d
			,@e
			,@f
			,@g;

		SET @counter1 = @counter1 + 1;
	END

	--Below is the sql for the last attribute of the list
	BEGIN
		IF EXISTS (
				SELECT COLUMN_NAME
					,WD_VALUE
					,STG_VALUE
				FROM SSISPi_FIN_Transformed_Data.FIN_AUDIT_DATA_COMPARISON_CONFIG
				WHERE TEMP1 = 'REPLACE_FUNCTION'
					AND TEMP2 = 'STAGING'
					AND COLUMN_NAME = @b
					AND Extract_Name = @g
				)
		BEGIN
			SELECT @COL_NAME = COLUMN_NAME
				,@WD_VALUE = WD_VALUE
				,@STG_VALUE = STG_VALUE
			FROM SSISPi_FIN_Transformed_Data.FIN_AUDIT_DATA_COMPARISON_CONFIG
			WHERE TEMP1 = 'REPLACE_FUNCTION'
				AND TEMP2 = 'STAGING'
				AND COLUMN_NAME = @b
				AND Extract_Name = @g;

			SET @vCreate_Sql1 = @vCreate_Sql1 + 'select T3.SUBJECT_AREA AS SUBJECT_AREA, T1.SOURCE_SYSTEM AS SOURCE_SYSTEM, T1.EXTRACT_NAME as EXTRACT_NAME, T1.ALTERNATE_KEY_COLUMN AS ALTERNATE_KEY,
T1.ALTERNATE_KEY AS ALTERNATE_KEY_VALUE,
''' + @b + ''' AS COLUMN_NAME,
CONVERT(NVARCHAR(500),T1.' + @b + ') AS VALUE_IN_STAGE,
CASE WHEN CONVERT(NVARCHAR(500),T2.' + @b + ') = '''' THEN NULL ELSE CONVERT(NVARCHAR(500),T2.' + @b + ') END AS VALUE_IN_WORKDAY,
''Mismatch between WorkDay and Staging'' AS ERROR_DESCRIPTION,
T4.BATCH_ID,
T4.LOAD_DATETIME
FROM (select a.*,' + @f + ' AS AK, b.EXTRACT_NAME, b.ALTERNATE_KEY_COLUMN from SSISPi_FIN_Transformed_Data.' + @a + ' a 
			inner join SSISPi_FIN_Transformed_Data.FIN_EXTRACT_CONFIG b
			on ''' + @a + ''' = b.STAGING_TABLE) T1
            INNER JOIN SSISPi_FIN_Transformed_Data.WD_EXTRACT_' + @a + 
				' T2
               ON T1.AK = T2.ALTERNATE_KEY
			LEFT JOIN (SELECT DISTINCT REPLACE(REPLACE(SUBJECT_AREA,''-AU'',''''),''-VN'','''') AS SUBJECT_AREA, REPLACE(REPLACE(EXTRACT_NAME,''_AU'',''''),''_VN'','''') AS EXTRACT_NAME FROM SSISPi_FIN_Transformed_Data.FIN_AUDIT_MAP_EXTRACT_AK) T3
				ON T1.EXTRACT_NAME = T3.EXTRACT_NAME
			LEFT JOIN (select distinct BATCH_ID, LOAD_DATETIME from SSISPi_FIN_Transformed_Data.WD_EXTRACT_' + @a + ') T4
				ON 1 = 1
			WHERE ' + @STG_VALUE + ' != ISNULL(T2.' + @b + ','''')';
		END

		IF NOT EXISTS (
				SELECT COLUMN_NAME
					,WD_VALUE
					,STG_VALUE
				FROM SSISPi_FIN_Transformed_Data.FIN_AUDIT_DATA_COMPARISON_CONFIG
				WHERE TEMP1 = 'REPLACE_FUNCTION'
					AND TEMP2 = 'STAGING'
					AND COLUMN_NAME = @b
					AND Extract_Name = @g
				)
			AND NOT EXISTS (
				SELECT COLUMN_NAME
					,WD_VALUE
					,STG_VALUE
				FROM SSISPi_FIN_Transformed_Data.FIN_AUDIT_DATA_COMPARISON_CONFIG
				WHERE TEMP1 = 'REMOVE_COLUMN'
					AND TEMP2 = 'STAGING'
					AND COLUMN_NAME = @b
					AND Extract_Name = @g
				)
		BEGIN
			SET @vCreate_Sql1 = @vCreate_Sql1 + 'select T3.SUBJECT_AREA AS SUBJECT_AREA, T1.SOURCE_SYSTEM AS SOURCE_SYSTEM, T1.EXTRACT_NAME as EXTRACT_NAME, T1.ALTERNATE_KEY_COLUMN AS ALTERNATE_KEY,
T1.ALTERNATE_KEY AS ALTERNATE_KEY_VALUE,
''' + @b + ''' AS COLUMN_NAME,
CONVERT(NVARCHAR(500),T1.' + @b + ') AS VALUE_IN_STAGE,
CASE WHEN CONVERT(NVARCHAR(500),T2.' + @b + ') = '''' THEN NULL ELSE CONVERT(NVARCHAR(500),T2.' + @b + ') END AS VALUE_IN_WORKDAY,
''Mismatch between WorkDay and Staging'' AS ERROR_DESCRIPTION,
T4.BATCH_ID,
T4.LOAD_DATETIME
FROM (select a.*,' + @f + ' AS AK, b.EXTRACT_NAME, b.ALTERNATE_KEY_COLUMN from SSISPi_FIN_Transformed_Data.' + @a + ' a 
			inner join SSISPi_FIN_Transformed_Data.FIN_EXTRACT_CONFIG b
			on ''' + @a + ''' = b.STAGING_TABLE) T1
            INNER JOIN SSISPi_FIN_Transformed_Data.WD_EXTRACT_' + @a + 
				' T2
               ON T1.AK = T2.ALTERNATE_KEY
			LEFT JOIN (SELECT DISTINCT REPLACE(REPLACE(SUBJECT_AREA,''-AU'',''''),''-VN'','''') AS SUBJECT_AREA, REPLACE(REPLACE(EXTRACT_NAME,''_AU'',''''),''_VN'','''') AS EXTRACT_NAME FROM SSISPi_FIN_Transformed_Data.FIN_AUDIT_MAP_EXTRACT_AK) T3
				ON T1.EXTRACT_NAME = T3.EXTRACT_NAME
			LEFT JOIN (select distinct BATCH_ID, LOAD_DATETIME from SSISPi_FIN_Transformed_Data.WD_EXTRACT_' + @a + ') T4
				ON 1 = 1
            WHERE CASE WHEN T1.' + @b + ' = ''Y'' THEN ''1'' WHEN T1.' + @b + ' = ''N'' THEN ''0'' ELSE ISNULL(T1.' + @b + ','''') END != ISNULL(T2.' + @b + ','''')';
		END
	END

	CLOSE cursor_temp1;

	DEALLOCATE cursor_temp1;
END

IF (@cnt = 0)
BEGIN
	CLOSE cursor_temp1;

	DEALLOCATE cursor_temp1;

	SET @vCreate_Sql1 = 'select '''' as SUBJECT_AREA, '''' as SOURCE_SYSTEM, '''' as EXTRACT_NAME, '''' AS ALTERNATE_KEY, '''' AS ALTERNATE_KEY_VALUE,
'''' AS COLUMN_NAME, '''' AS VALUE_IN_STAGE, '''' AS VALUE_IN_WORKDAY, '''' AS ERROR_DESCRIPTION, '''' AS BATCH_ID, '''' AS LOAD_DATETIME';
END

---2
DECLARE cursor_temp2 CURSOR
FOR
SELECT AK.STAGING_TABLE
	,COL.COLUMN_NAME
	,COL.DATA_TYPE
	,COL.NUMERIC_PRECISION
	,COL.NUMERIC_SCALE
	,AK.ALTERNATE_KEY_REPORTING
	,AK.EXTRACT_NAME
FROM SSISPi_FIN_Transformed_Data.FIN_EXTRACT_CONFIG AK
INNER JOIN INFORMATION_SCHEMA.COLUMNS COL ON AK.STAGING_TABLE = COL.TABLE_NAME
	AND TABLE_SCHEMA = 'SSISPi_FIN_Transformed_Data'
	AND AK.IS_ACTIVE = 1
	AND COLUMN_NAME NOT IN (
		'SOURCE_SYSTEM'
		,'LOAD_DATETIME'
		,'BATCH_ID'
		,'PACKAGE_NAME'
		,'ALTERNATE_KEY'
		)
	AND DATA_TYPE = 'decimal'
	AND EXTRACT_NAME = ISNULL(@wd_extract_name, EXTRACT_NAME);

SELECT @cnt = count(*)
FROM SSISPi_FIN_Transformed_Data.FIN_EXTRACT_CONFIG AK
INNER JOIN INFORMATION_SCHEMA.COLUMNS COL ON AK.STAGING_TABLE = COL.TABLE_NAME
	AND TABLE_SCHEMA = 'SSISPi_FIN_Transformed_Data'
	AND AK.IS_ACTIVE = 1
	AND COLUMN_NAME NOT IN (
		'SOURCE_SYSTEM'
		,'LOAD_DATETIME'
		,'BATCH_ID'
		,'PACKAGE_NAME'
		,'ALTERNATE_KEY'
		)
	AND DATA_TYPE = 'decimal'
	AND EXTRACT_NAME = ISNULL(@wd_extract_name, EXTRACT_NAME);

OPEN cursor_temp2;

FETCH NEXT
FROM cursor_temp2
INTO @a
	,@b
	,@c
	,@d
	,@e
	,@f
	,@g;

IF (@cnt != 0)
BEGIN
	WHILE (@counter2 < @cnt)
	BEGIN
		--Checking if the column is in the config table and needs a modification
		IF EXISTS (
				SELECT COLUMN_NAME
					,WD_VALUE
					,STG_VALUE
				FROM SSISPi_FIN_Transformed_Data.FIN_AUDIT_DATA_COMPARISON_CONFIG
				WHERE TEMP1 = 'REPLACE_FUNCTION'
					AND TEMP2 = 'STAGING'
					AND COLUMN_NAME = @b
					AND Extract_Name = @g
				)
		BEGIN
			SELECT @COL_NAME = COLUMN_NAME
				,@WD_VALUE = WD_VALUE
				,@STG_VALUE = STG_VALUE
			FROM SSISPi_FIN_Transformed_Data.FIN_AUDIT_DATA_COMPARISON_CONFIG
			WHERE TEMP1 = 'REPLACE_FUNCTION'
				AND TEMP2 = 'STAGING'
				AND COLUMN_NAME = @b
				AND Extract_Name = @g;

			SET @vCreate_Sql2 = @vCreate_Sql2 + 'select T3.SUBJECT_AREA AS SUBJECT_AREA, T1.SOURCE_SYSTEM AS SOURCE_SYSTEM, T1.EXTRACT_NAME as EXTRACT_NAME, T1.ALTERNATE_KEY_COLUMN AS ALTERNATE_KEY,
					T1.ALTERNATE_KEY AS ALTERNATE_KEY_VALUE,
					''' + @b + ''' AS COLUMN_NAME,
					CONVERT(NVARCHAR(500),T1.' + @b + ') AS VALUE_IN_STAGE,
					CASE WHEN CONVERT(NVARCHAR(500),T2.' + @b + ') = '''' THEN NULL ELSE CONVERT(NVARCHAR(500),T2.' + @b + ') END AS VALUE_IN_WORKDAY,
					''Mismatch between WorkDay and Staging'' AS ERROR_DESCRIPTION,
					T4.BATCH_ID,
					T4.LOAD_DATETIME
					FROM (select a.*,' + @f + ' AS AK, b.EXTRACT_NAME, b.ALTERNATE_KEY_COLUMN from SSISPi_FIN_Transformed_Data.' + @a + ' a 
			inner join SSISPi_FIN_Transformed_Data.FIN_EXTRACT_CONFIG b
			on ''' + @a + ''' = b.STAGING_TABLE) T1
            INNER JOIN SSISPi_FIN_Transformed_Data.WD_EXTRACT_' + @a + 
				' T2
               ON T1.AK = T2.ALTERNATE_KEY
			LEFT JOIN (SELECT DISTINCT REPLACE(REPLACE(SUBJECT_AREA,''-AU'',''''),''-VN'','''') AS SUBJECT_AREA, REPLACE(REPLACE(EXTRACT_NAME,''_AU'',''''),''_VN'','''') AS EXTRACT_NAME FROM SSISPi_FIN_Transformed_Data.FIN_AUDIT_MAP_EXTRACT_AK) T3
				ON T1.EXTRACT_NAME = T3.EXTRACT_NAME
			LEFT JOIN (select distinct BATCH_ID, LOAD_DATETIME from SSISPi_FIN_Transformed_Data.WD_EXTRACT_' + @a + ') T4
				ON 1 = 1
            WHERE ' + @STG_VALUE + ' != ISNULL(CONVERT(decimal(' + @d + ',' + @e + '),T2.' + @b + '),0)';
			SET @vCreate_Sql2 = @vCreate_Sql2 + ' union ';
		END

		IF NOT EXISTS (
				SELECT COLUMN_NAME
					,WD_VALUE
					,STG_VALUE
				FROM SSISPi_FIN_Transformed_Data.FIN_AUDIT_DATA_COMPARISON_CONFIG
				WHERE TEMP1 = 'REPLACE_FUNCTION'
					AND TEMP2 = 'STAGING'
					AND COLUMN_NAME = @b
					AND Extract_Name = @g
				)
			AND NOT EXISTS (
				SELECT COLUMN_NAME
					,WD_VALUE
					,STG_VALUE
				FROM SSISPi_FIN_Transformed_Data.FIN_AUDIT_DATA_COMPARISON_CONFIG
				WHERE TEMP1 = 'REMOVE_COLUMN'
					AND TEMP2 = 'STAGING'
					AND COLUMN_NAME = @b
					AND Extract_Name = @g
				)
		BEGIN
			SET @vCreate_Sql2 = @vCreate_Sql2 + 'select T3.SUBJECT_AREA AS SUBJECT_AREA, T1.SOURCE_SYSTEM AS SOURCE_SYSTEM, T1.EXTRACT_NAME as EXTRACT_NAME, T1.ALTERNATE_KEY_COLUMN AS ALTERNATE_KEY,
T1.ALTERNATE_KEY AS ALTERNATE_KEY_VALUE,
''' + @b + ''' AS COLUMN_NAME,
CONVERT(NVARCHAR(500),T1.' + @b + ') AS VALUE_IN_STAGE,
CASE WHEN CONVERT(NVARCHAR(500),T2.' + @b + ') = '''' THEN NULL ELSE CONVERT(NVARCHAR(500),T2.' + @b + ') END AS VALUE_IN_WORKDAY,
''Mismatch between WorkDay and Staging'' AS ERROR_DESCRIPTION,
T4.BATCH_ID,
T4.LOAD_DATETIME
FROM (select a.*,' + @f + ' AS AK, b.EXTRACT_NAME, b.ALTERNATE_KEY_COLUMN from SSISPi_FIN_Transformed_Data.' + @a + ' a 
			inner join SSISPi_FIN_Transformed_Data.FIN_EXTRACT_CONFIG b
			on ''' + @a + ''' = b.STAGING_TABLE) T1
            INNER JOIN SSISPi_FIN_Transformed_Data.WD_EXTRACT_' + @a + 
				' T2
               ON T1.AK = T2.ALTERNATE_KEY
			LEFT JOIN (SELECT DISTINCT REPLACE(REPLACE(SUBJECT_AREA,''-AU'',''''),''-VN'','''') AS SUBJECT_AREA, REPLACE(REPLACE(EXTRACT_NAME,''_AU'',''''),''_VN'','''') AS EXTRACT_NAME FROM SSISPi_FIN_Transformed_Data.FIN_AUDIT_MAP_EXTRACT_AK) T3
				ON T1.EXTRACT_NAME = T3.EXTRACT_NAME
			LEFT JOIN (select distinct BATCH_ID, LOAD_DATETIME from SSISPi_FIN_Transformed_Data.WD_EXTRACT_' + @a + ') T4
				ON 1 = 1
            WHERE ISNULL(T1.' + @b + ',0) != ISNULL(CONVERT(decimal(' + @d + ',' + @e + '),T2.' + @b + '),0)';
			SET @vCreate_Sql2 = @vCreate_Sql2 + ' union ';
		END

		FETCH NEXT
		FROM cursor_temp2
		INTO @a
			,@b
			,@c
			,@d
			,@e
			,@f
			,@g;

		SET @counter2 = @counter2 + 1;
	END

	--Below is the sql for the last attribute of the list
	BEGIN
		IF EXISTS (
				SELECT COLUMN_NAME
					,WD_VALUE
					,STG_VALUE
				FROM SSISPi_FIN_Transformed_Data.FIN_AUDIT_DATA_COMPARISON_CONFIG
				WHERE TEMP1 = 'REPLACE_FUNCTION'
					AND TEMP2 = 'STAGING'
					AND COLUMN_NAME = @b
					AND Extract_Name = @g
				)
		BEGIN
			SELECT @COL_NAME = COLUMN_NAME
				,@WD_VALUE = WD_VALUE
				,@STG_VALUE = STG_VALUE
			FROM SSISPi_FIN_Transformed_Data.FIN_AUDIT_DATA_COMPARISON_CONFIG
			WHERE TEMP1 = 'REPLACE_FUNCTION'
				AND TEMP2 = 'STAGING'
				AND COLUMN_NAME = @b
				AND Extract_Name = @g;

			SET @vCreate_Sql2 = @vCreate_Sql2 + 'select T3.SUBJECT_AREA AS SUBJECT_AREA, T1.SOURCE_SYSTEM AS SOURCE_SYSTEM, T1.EXTRACT_NAME as EXTRACT_NAME, T1.ALTERNATE_KEY_COLUMN AS ALTERNATE_KEY,
					T1.ALTERNATE_KEY AS ALTERNATE_KEY_VALUE,
					''' + @b + ''' AS COLUMN_NAME,
					CONVERT(NVARCHAR(500),T1.' + @b + ') AS VALUE_IN_STAGE,
					CASE WHEN CONVERT(NVARCHAR(500),T2.' + @b + ') = '''' THEN NULL ELSE CONVERT(NVARCHAR(500),T2.' + @b + ') END AS VALUE_IN_WORKDAY,
					''Mismatch between WorkDay and Staging'' AS ERROR_DESCRIPTION,
					T4.BATCH_ID,
					T4.LOAD_DATETIME
					FROM (select a.*,' + @f + ' AS AK, b.EXTRACT_NAME, b.ALTERNATE_KEY_COLUMN from SSISPi_FIN_Transformed_Data.' + @a + ' a 
			inner join SSISPi_FIN_Transformed_Data.FIN_EXTRACT_CONFIG b
			on ''' + @a + ''' = b.STAGING_TABLE) T1
            INNER JOIN SSISPi_FIN_Transformed_Data.WD_EXTRACT_' + @a + 
				' T2
               ON T1.AK = T2.ALTERNATE_KEY
			LEFT JOIN (SELECT DISTINCT REPLACE(REPLACE(SUBJECT_AREA,''-AU'',''''),''-VN'','''') AS SUBJECT_AREA, REPLACE(REPLACE(EXTRACT_NAME,''_AU'',''''),''_VN'','''') AS EXTRACT_NAME FROM SSISPi_FIN_Transformed_Data.FIN_AUDIT_MAP_EXTRACT_AK) T3
				ON T1.EXTRACT_NAME = T3.EXTRACT_NAME
			LEFT JOIN (select distinct BATCH_ID, LOAD_DATETIME from SSISPi_FIN_Transformed_Data.WD_EXTRACT_' + @a + ') T4
				ON 1 = 1
            WHERE ' + @STG_VALUE + ' != ISNULL(CONVERT(decimal(' + @d + ',' + @e + '),T2.' + @b + '),0)';
		END

		IF NOT EXISTS (
				SELECT COLUMN_NAME
					,WD_VALUE
					,STG_VALUE
				FROM SSISPi_FIN_Transformed_Data.FIN_AUDIT_DATA_COMPARISON_CONFIG
				WHERE TEMP1 = 'REPLACE_FUNCTION'
					AND TEMP2 = 'STAGING'
					AND COLUMN_NAME = @b
					AND Extract_Name = @g
				)
			AND NOT EXISTS (
				SELECT COLUMN_NAME
					,WD_VALUE
					,STG_VALUE
				FROM SSISPi_FIN_Transformed_Data.FIN_AUDIT_DATA_COMPARISON_CONFIG
				WHERE TEMP1 = 'REMOVE_COLUMN'
					AND TEMP2 = 'STAGING'
					AND COLUMN_NAME = @b
					AND Extract_Name = @g
				)
		BEGIN
			SET @vCreate_Sql2 = @vCreate_Sql2 + 'select T3.SUBJECT_AREA AS SUBJECT_AREA, T1.SOURCE_SYSTEM AS SOURCE_SYSTEM, T1.EXTRACT_NAME as EXTRACT_NAME, T1.ALTERNATE_KEY_COLUMN AS ALTERNATE_KEY,
T1.ALTERNATE_KEY AS ALTERNATE_KEY_VALUE,
''' + @b + ''' AS COLUMN_NAME,
CONVERT(NVARCHAR(500),T1.' + @b + ') AS VALUE_IN_STAGE,
CASE WHEN CONVERT(NVARCHAR(500),T2.' + @b + ') = '''' THEN NULL ELSE CONVERT(NVARCHAR(500),T2.' + @b + ') END AS VALUE_IN_WORKDAY,
''Mismatch between WorkDay and Staging'' AS ERROR_DESCRIPTION,
T4.BATCH_ID,
T4.LOAD_DATETIME
FROM (select a.*,' + @f + ' AS AK, b.EXTRACT_NAME, b.ALTERNATE_KEY_COLUMN from SSISPi_FIN_Transformed_Data.' + @a + ' a 
			inner join SSISPi_FIN_Transformed_Data.FIN_EXTRACT_CONFIG b
			on ''' + @a + ''' = b.STAGING_TABLE) T1
            INNER JOIN SSISPi_FIN_Transformed_Data.WD_EXTRACT_' + @a + 
				' T2
               ON T1.AK = T2.ALTERNATE_KEY
			LEFT JOIN (SELECT DISTINCT REPLACE(REPLACE(SUBJECT_AREA,''-AU'',''''),''-VN'','''') AS SUBJECT_AREA, REPLACE(REPLACE(EXTRACT_NAME,''_AU'',''''),''_VN'','''') AS EXTRACT_NAME FROM SSISPi_FIN_Transformed_Data.FIN_AUDIT_MAP_EXTRACT_AK) T3
				ON T1.EXTRACT_NAME = T3.EXTRACT_NAME
			LEFT JOIN (select distinct BATCH_ID, LOAD_DATETIME from SSISPi_FIN_Transformed_Data.WD_EXTRACT_' + @a + ') T4
				ON 1 = 1
            WHERE ISNULL(T1.' + @b + ',0) != ISNULL(CONVERT(decimal(' + @d + ',' + @e + '),T2.' + @b + '),0)';
		END
	END

	CLOSE cursor_temp2;

	DEALLOCATE cursor_temp2;
END

IF (@cnt = 0)
BEGIN
	CLOSE cursor_temp2;

	DEALLOCATE cursor_temp2;

	SET @vCreate_Sql2 = 'select '''' as SUBJECT_AREA, '''' as SOURCE_SYSTEM, '''' as EXTRACT_NAME, '''' AS ALTERNATE_KEY, '''' AS ALTERNATE_KEY_VALUE,
'''' AS COLUMN_NAME, '''' AS VALUE_IN_STAGE, '''' AS VALUE_IN_WORKDAY, '''' AS ERROR_DESCRIPTION, '''' AS BATCH_ID, '''' AS LOAD_DATETIME';
END

---3
DECLARE cursor_temp3 CURSOR
FOR
SELECT AK.STAGING_TABLE
	,COL.COLUMN_NAME
	,COL.DATA_TYPE
	,COL.NUMERIC_PRECISION
	,COL.NUMERIC_SCALE
	,AK.ALTERNATE_KEY_REPORTING
	,AK.EXTRACT_NAME
FROM SSISPi_FIN_Transformed_Data.FIN_EXTRACT_CONFIG AK
INNER JOIN INFORMATION_SCHEMA.COLUMNS COL ON AK.STAGING_TABLE = COL.TABLE_NAME
	AND TABLE_SCHEMA = 'SSISPi_FIN_Transformed_Data'
	AND AK.IS_ACTIVE = 1
	AND COLUMN_NAME NOT IN (
		'SOURCE_SYSTEM'
		,'LOAD_DATETIME'
		,'BATCH_ID'
		,'PACKAGE_NAME'
		,'ALTERNATE_KEY'
		)
	AND DATA_TYPE = 'date'
	AND EXTRACT_NAME = ISNULL(@wd_extract_name, EXTRACT_NAME);

SELECT @cnt = count(*)
FROM SSISPi_FIN_Transformed_Data.FIN_EXTRACT_CONFIG AK
INNER JOIN INFORMATION_SCHEMA.COLUMNS COL ON AK.STAGING_TABLE = COL.TABLE_NAME
	AND TABLE_SCHEMA = 'SSISPi_FIN_Transformed_Data'
	AND AK.IS_ACTIVE = 1
	AND COLUMN_NAME NOT IN (
		'SOURCE_SYSTEM'
		,'LOAD_DATETIME'
		,'BATCH_ID'
		,'PACKAGE_NAME'
		,'ALTERNATE_KEY'
		)
	AND DATA_TYPE = 'date'
	AND EXTRACT_NAME = ISNULL(@wd_extract_name, EXTRACT_NAME);

OPEN cursor_temp3;

FETCH NEXT
FROM cursor_temp3
INTO @a
	,@b
	,@c
	,@d
	,@e
	,@f
	,@g;

IF (@cnt != 0)
BEGIN
	WHILE (@counter3 < @cnt)
	BEGIN
		IF NOT EXISTS (
				SELECT COLUMN_NAME
					,WD_VALUE
					,STG_VALUE
				FROM SSISPi_FIN_Transformed_Data.FIN_AUDIT_DATA_COMPARISON_CONFIG
				WHERE TEMP1 = 'REMOVE_COLUMN'
					AND TEMP2 = 'STAGING'
					AND COLUMN_NAME = @b
					AND Extract_Name = @g
				)
		BEGIN
			SET @vCreate_Sql3 = @vCreate_Sql3 + 'select T3.SUBJECT_AREA AS SUBJECT_AREA, T1.SOURCE_SYSTEM AS SOURCE_SYSTEM, T1.EXTRACT_NAME as EXTRACT_NAME, T1.ALTERNATE_KEY_COLUMN AS ALTERNATE_KEY,
T1.ALTERNATE_KEY AS ALTERNATE_KEY_VALUE,
''' + @b + ''' AS COLUMN_NAME,
CONVERT(NVARCHAR(500),T1.' + @b + ') AS VALUE_IN_STAGE,
CASE WHEN CONVERT(NVARCHAR(500),T2.' + @b + ') = '''' THEN NULL ELSE CONVERT(NVARCHAR(500),T2.' + @b + ') END AS VALUE_IN_WORKDAY,
''Mismatch between WorkDay and Staging'' AS ERROR_DESCRIPTION,
T4.BATCH_ID,
T4.LOAD_DATETIME
FROM (select a.*,' + @f + ' AS AK, b.EXTRACT_NAME, b.ALTERNATE_KEY_COLUMN from SSISPi_FIN_Transformed_Data.' + @a + ' a 
			inner join SSISPi_FIN_Transformed_Data.FIN_EXTRACT_CONFIG b
			on ''' + @a + ''' = b.STAGING_TABLE) T1
            INNER JOIN SSISPi_FIN_Transformed_Data.WD_EXTRACT_' + @a + 
				' T2
               ON T1.AK = T2.ALTERNATE_KEY
			LEFT JOIN (SELECT DISTINCT REPLACE(REPLACE(SUBJECT_AREA,''-AU'',''''),''-VN'','''') AS SUBJECT_AREA, REPLACE(REPLACE(EXTRACT_NAME,''_AU'',''''),''_VN'','''') AS EXTRACT_NAME FROM SSISPi_FIN_Transformed_Data.FIN_AUDIT_MAP_EXTRACT_AK) T3
				ON T1.EXTRACT_NAME = T3.EXTRACT_NAME
			LEFT JOIN (select distinct BATCH_ID, LOAD_DATETIME from SSISPi_FIN_Transformed_Data.WD_EXTRACT_' + @a + ') T4
				ON 1 = 1
            WHERE ISNULL(T1.' + @b + ','''') != ISNULL(T2.' + @b + ','''')';
			SET @vCreate_Sql3 = @vCreate_Sql3 + ' union ';
		END

		FETCH NEXT
		FROM cursor_temp3
		INTO @a
			,@b
			,@c
			,@d
			,@e
			,@f
			,@g;

		SET @counter3 = @counter3 + 1;
	END

	BEGIN
		IF NOT EXISTS (
				SELECT COLUMN_NAME
					,WD_VALUE
					,STG_VALUE
				FROM SSISPi_FIN_Transformed_Data.FIN_AUDIT_DATA_COMPARISON_CONFIG
				WHERE TEMP1 = 'REMOVE_COLUMN'
					AND TEMP2 = 'STAGING'
					AND COLUMN_NAME = @b
					AND Extract_Name = @g
				)
		BEGIN
			SET @vCreate_Sql3 = @vCreate_Sql3 + 'select T3.SUBJECT_AREA AS SUBJECT_AREA, T1.SOURCE_SYSTEM AS SOURCE_SYSTEM, T1.EXTRACT_NAME as EXTRACT_NAME, T1.ALTERNATE_KEY_COLUMN AS ALTERNATE_KEY,
T1.ALTERNATE_KEY AS ALTERNATE_KEY_VALUE,
''' + @b + ''' AS COLUMN_NAME,
CONVERT(NVARCHAR(500),T1.' + @b + ') AS VALUE_IN_STAGE,
CASE WHEN CONVERT(NVARCHAR(500),T2.' + @b + ') = '''' THEN NULL ELSE CONVERT(NVARCHAR(500),T2.' + @b + ') END AS VALUE_IN_WORKDAY,
''Mismatch between WorkDay and Staging'' AS ERROR_DESCRIPTION,
T4.BATCH_ID,
T4.LOAD_DATETIME
FROM (select a.*,' + @f + ' AS AK, b.EXTRACT_NAME, b.ALTERNATE_KEY_COLUMN from SSISPi_FIN_Transformed_Data.' + @a + ' a 
			inner join SSISPi_FIN_Transformed_Data.FIN_EXTRACT_CONFIG b
			on ''' + @a + ''' = b.STAGING_TABLE) T1
            INNER JOIN SSISPi_FIN_Transformed_Data.WD_EXTRACT_' + @a + 
				' T2
               ON T1.AK = T2.ALTERNATE_KEY
			LEFT JOIN (SELECT DISTINCT REPLACE(REPLACE(SUBJECT_AREA,''-AU'',''''),''-VN'','''') AS SUBJECT_AREA, REPLACE(REPLACE(EXTRACT_NAME,''_AU'',''''),''_VN'','''') AS EXTRACT_NAME FROM SSISPi_FIN_Transformed_Data.FIN_AUDIT_MAP_EXTRACT_AK) T3
				ON T1.EXTRACT_NAME = T3.EXTRACT_NAME
			LEFT JOIN (select distinct BATCH_ID, LOAD_DATETIME from SSISPi_FIN_Transformed_Data.WD_EXTRACT_' + @a + ') T4
				ON 1 = 1
            WHERE ISNULL(T1.' + @b + ','''') != ISNULL(T2.' + @b + ','''')';
		END
	END

	CLOSE cursor_temp3;

	DEALLOCATE cursor_temp3;
END

IF (@cnt = 0)
BEGIN
	CLOSE cursor_temp3;

	DEALLOCATE cursor_temp3;

	SET @vCreate_Sql3 = 'select '''' as SUBJECT_AREA, '''' as SOURCE_SYSTEM, '''' as EXTRACT_NAME, '''' AS ALTERNATE_KEY, '''' AS ALTERNATE_KEY_VALUE,
'''' AS COLUMN_NAME, '''' AS VALUE_IN_STAGE, '''' AS VALUE_IN_WORKDAY, '''' AS ERROR_DESCRIPTION, '''' AS BATCH_ID, '''' AS LOAD_DATETIME';
END

---4
--SET @counter = 1;
DECLARE cursor_temp4 CURSOR
FOR
SELECT AK.STAGING_TABLE
	,COL.COLUMN_NAME
	,COL.DATA_TYPE
	,COL.NUMERIC_PRECISION
	,COL.NUMERIC_SCALE
	,AK.ALTERNATE_KEY_REPORTING
	,AK.EXTRACT_NAME
FROM SSISPi_FIN_Transformed_Data.FIN_EXTRACT_CONFIG AK
INNER JOIN INFORMATION_SCHEMA.COLUMNS COL ON AK.STAGING_TABLE = COL.TABLE_NAME
	AND TABLE_SCHEMA = 'SSISPi_FIN_Transformed_Data'
	AND AK.IS_ACTIVE = 1
	AND COLUMN_NAME NOT IN (
		'SOURCE_SYSTEM'
		,'LOAD_DATETIME'
		,'BATCH_ID'
		,'PACKAGE_NAME'
		,'ALTERNATE_KEY'
		)
	AND DATA_TYPE = 'int'
	AND EXTRACT_NAME = ISNULL(@wd_extract_name, EXTRACT_NAME);

SELECT @cnt = count(*)
FROM SSISPi_FIN_Transformed_Data.FIN_EXTRACT_CONFIG AK
INNER JOIN INFORMATION_SCHEMA.COLUMNS COL ON AK.STAGING_TABLE = COL.TABLE_NAME
	AND TABLE_SCHEMA = 'SSISPi_FIN_Transformed_Data'
	AND AK.IS_ACTIVE = 1
	AND COLUMN_NAME NOT IN (
		'SOURCE_SYSTEM'
		,'LOAD_DATETIME'
		,'BATCH_ID'
		,'PACKAGE_NAME'
		,'ALTERNATE_KEY'
		)
	AND DATA_TYPE = 'int'
	AND EXTRACT_NAME = ISNULL(@wd_extract_name, EXTRACT_NAME);

OPEN cursor_temp4;

FETCH NEXT
FROM cursor_temp4
INTO @a
	,@b
	,@c
	,@d
	,@e
	,@f
	,@g;

IF (@cnt != 0)
BEGIN
	WHILE (@counter4 < @cnt)
	BEGIN
		SET @vCreate_Sql4 = @vCreate_Sql4 + 'select T3.SUBJECT_AREA AS SUBJECT_AREA, T1.SOURCE_SYSTEM AS SOURCE_SYSTEM, T1.EXTRACT_NAME as EXTRACT_NAME, T1.ALTERNATE_KEY_COLUMN AS ALTERNATE_KEY,
T1.ALTERNATE_KEY AS ALTERNATE_KEY_VALUE,
''' + @b + ''' AS COLUMN_NAME,
CONVERT(NVARCHAR(500),T1.' + @b + ') AS VALUE_IN_STAGE,
CASE WHEN CONVERT(NVARCHAR(500),T2.' + @b + ') = '''' THEN NULL ELSE CONVERT(NVARCHAR(500),T2.' + @b + ') END AS VALUE_IN_WORKDAY,
''Mismatch between WorkDay and Staging'' AS ERROR_DESCRIPTION,
T4.BATCH_ID,
T4.LOAD_DATETIME
FROM (select a.*,' + @f + ' AS AK, b.EXTRACT_NAME, b.ALTERNATE_KEY_COLUMN from SSISPi_FIN_Transformed_Data.' + @a + ' a 
			inner join SSISPi_FIN_Transformed_Data.FIN_EXTRACT_CONFIG b
			on ''' + @a + ''' = b.STAGING_TABLE) T1
            INNER JOIN SSISPi_FIN_Transformed_Data.WD_EXTRACT_' + @a + 
			' T2
               ON T1.AK = T2.ALTERNATE_KEY
			LEFT JOIN (SELECT DISTINCT REPLACE(REPLACE(SUBJECT_AREA,''-AU'',''''),''-VN'','''') AS SUBJECT_AREA, REPLACE(REPLACE(EXTRACT_NAME,''_AU'',''''),''_VN'','''') AS EXTRACT_NAME FROM SSISPi_FIN_Transformed_Data.FIN_AUDIT_MAP_EXTRACT_AK) T3
				ON T1.EXTRACT_NAME = T3.EXTRACT_NAME
			LEFT JOIN (select distinct BATCH_ID, LOAD_DATETIME from SSISPi_FIN_Transformed_Data.WD_EXTRACT_' + @a + ') T4
				ON 1 = 1
            WHERE ISNULL(T1.' + @b + ',0) != ISNULL(CONVERT(int,T2.' + @b + '),0)';
		SET @vCreate_Sql4 = @vCreate_Sql4 + ' union ';

		FETCH NEXT
		FROM cursor_temp4
		INTO @a
			,@b
			,@c
			,@d
			,@e
			,@f
			,@g;

		SET @counter4 = @counter4 + 1;
	END

	BEGIN
		SET @vCreate_Sql4 = @vCreate_Sql4 + 'select T3.SUBJECT_AREA AS SUBJECT_AREA, T1.SOURCE_SYSTEM AS SOURCE_SYSTEM, T1.EXTRACT_NAME as EXTRACT_NAME, T1.ALTERNATE_KEY_COLUMN AS ALTERNATE_KEY,
T1.ALTERNATE_KEY AS ALTERNATE_KEY_VALUE,
''' + @b + ''' AS COLUMN_NAME,
CONVERT(NVARCHAR(500),T1.' + @b + ') AS VALUE_IN_STAGE,
CASE WHEN CONVERT(NVARCHAR(500),T2.' + @b + ') = '''' THEN NULL ELSE CONVERT(NVARCHAR(500),T2.' + @b + ') END AS VALUE_IN_WORKDAY,
''Mismatch between WorkDay and Staging'' AS ERROR_DESCRIPTION,
T4.BATCH_ID,
T4.LOAD_DATETIME
FROM (select a.*,' + @f + ' AS AK, b.EXTRACT_NAME, b.ALTERNATE_KEY_COLUMN from SSISPi_FIN_Transformed_Data.' + @a + ' a 
			inner join SSISPi_FIN_Transformed_Data.FIN_EXTRACT_CONFIG b
			on ''' + @a + ''' = b.STAGING_TABLE) T1
            INNER JOIN SSISPi_FIN_Transformed_Data.WD_EXTRACT_' + @a + 
			' T2
               ON T1.AK = T2.ALTERNATE_KEY
			LEFT JOIN (SELECT DISTINCT REPLACE(REPLACE(SUBJECT_AREA,''-AU'',''''),''-VN'','''') AS SUBJECT_AREA, REPLACE(REPLACE(EXTRACT_NAME,''_AU'',''''),''_VN'','''') AS EXTRACT_NAME FROM SSISPi_FIN_Transformed_Data.FIN_AUDIT_MAP_EXTRACT_AK) T3
				ON T1.EXTRACT_NAME = T3.EXTRACT_NAME
			LEFT JOIN (select distinct BATCH_ID, LOAD_DATETIME from SSISPi_FIN_Transformed_Data.WD_EXTRACT_' + @a + ') T4
				ON 1 = 1
            WHERE ISNULL(T1.' + @b + ',0) != ISNULL(CONVERT(int,T2.' + @b + '),0)';
	END

	CLOSE cursor_temp4;

	DEALLOCATE cursor_temp4;
END

IF (@cnt = 0)
BEGIN
	CLOSE cursor_temp4;

	DEALLOCATE cursor_temp4;

	SET @vCreate_Sql4 = 'select '''' as SUBJECT_AREA, '''' as SOURCE_SYSTEM, '''' as EXTRACT_NAME, '''' AS ALTERNATE_KEY, '''' AS ALTERNATE_KEY_VALUE,
'''' AS COLUMN_NAME, '''' AS VALUE_IN_STAGE, '''' AS VALUE_IN_WORKDAY, '''' AS ERROR_DESCRIPTION, '''' AS BATCH_ID, '''' AS LOAD_DATETIME';
END

IF @vCreate_Sql1 = ''
SET @vCreate_Sql1 = 'select '''' as SUBJECT_AREA, '''' as SOURCE_SYSTEM, '''' as EXTRACT_NAME, '''' AS ALTERNATE_KEY, '''' AS ALTERNATE_KEY_VALUE, '''' AS COLUMN_NAME, '''' AS VALUE_IN_STAGE, '''' AS VALUE_IN_WORKDAY, '''' AS ERROR_DESCRIPTION, '''' AS BATCH_ID, '''' AS LOAD_DATETIME';

IF @vCreate_Sql2 = ''
SET @vCreate_Sql2 = 'select '''' as SUBJECT_AREA, '''' as SOURCE_SYSTEM, '''' as EXTRACT_NAME, '''' AS ALTERNATE_KEY, '''' AS ALTERNATE_KEY_VALUE, '''' AS COLUMN_NAME, '''' AS VALUE_IN_STAGE, '''' AS VALUE_IN_WORKDAY, '''' AS ERROR_DESCRIPTION, '''' AS BATCH_ID, '''' AS LOAD_DATETIME';

IF @vCreate_Sql3 = ''
SET @vCreate_Sql3 = 'select '''' as SUBJECT_AREA, '''' as SOURCE_SYSTEM, '''' as EXTRACT_NAME, '''' AS ALTERNATE_KEY, '''' AS ALTERNATE_KEY_VALUE, '''' AS COLUMN_NAME, '''' AS VALUE_IN_STAGE, '''' AS VALUE_IN_WORKDAY, '''' AS ERROR_DESCRIPTION, '''' AS BATCH_ID, '''' AS LOAD_DATETIME';

IF @vCreate_Sql4 = ''
SET @vCreate_Sql4 = 'select '''' as SUBJECT_AREA, '''' as SOURCE_SYSTEM, '''' as EXTRACT_NAME, '''' AS ALTERNATE_KEY, '''' AS ALTERNATE_KEY_VALUE, '''' AS COLUMN_NAME, '''' AS VALUE_IN_STAGE, '''' AS VALUE_IN_WORKDAY, '''' AS ERROR_DESCRIPTION, '''' AS BATCH_ID, '''' AS LOAD_DATETIME';


INSERT INTO SSISPi_FIN_Transformed_Data.FIN_DATA_CONVERSION_CUSTOM_SOLUTION_REPORT_3_TEST
EXECUTE (@vCreate_Sql1 + ' union ' + @vCreate_Sql2 + ' union ' + @vCreate_Sql3 + ' union ' + @vCreate_Sql4);

DELETE
FROM SSISPi_FIN_Transformed_Data.FIN_DATA_CONVERSION_CUSTOM_SOLUTION_REPORT_3_TEST
WHERE BATCH_ID = 0;

--PRINT (@vCreate_Sql1 + ' union ' + @vCreate_Sql2 + ' union ' + @vCreate_Sql3 + ' union ' + @vCreate_Sql4);
GO


