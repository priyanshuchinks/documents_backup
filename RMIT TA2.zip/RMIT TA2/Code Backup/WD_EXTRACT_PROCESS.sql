USE [SAPBodsPi_ProfData_Prod]
GO

/****** Object:  StoredProcedure [SSISPi_FIN_Transformed_Data].[WD_EXTRACT_PROCESS]    Script Date: 17/06/2021 3:17:46 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO







CREATE PROCEDURE [SSISPi_FIN_Transformed_Data].[WD_EXTRACT_PROCESS] @ip_extract_name NVARCHAR(200)
AS
BEGIN
	DECLARE @DATABASE NVARCHAR(250) = 'SAPBodsPi_ProfData_Prod'
	DECLARE @TABLE_SCHEMA NVARCHAR(250) = 'SSISPi_FIN_Transformed_Data'
	DECLARE @EXTRACT NVARCHAR(250) = @ip_extract_name
	DECLARE @EXTRACT_FILE NVARCHAR(250)
	DECLARE @INPUT_FILE NVARCHAR(250)
	DECLARE @TABLE_NAME VARCHAR(250)
	DECLARE @ALTERNATE_KEY VARCHAR(250)
	DECLARE @a VARCHAR(250)
	DECLARE @b VARCHAR(250)
	DECLARE @SQL_DROP_TABLE NVARCHAR(max) = ''
	DECLARE @SQL_INSERT_TABLE NVARCHAR(max) = ''
	DECLARE @vCreate_Sql NVARCHAR(max) = ''
	DECLARE @sql1 NVARCHAR(max) = ''
	DECLARE @sql2 NVARCHAR(max) = ''
	DECLARE @sql3 NVARCHAR(max) = ''
	DECLARE @sql4 NVARCHAR(max) = ''
	DECLARE @sql5 NVARCHAR(max) = ''
	DECLARE @STG_VALUE NVARCHAR(max)
	DECLARE @WD_VALUE NVARCHAR(max)
	DECLARE @COL_NAME NVARCHAR(max)
	DECLARE @counter1 INT = 1;
	DECLARE @counter2 INT = 1;
	DECLARE @counter3 INT = 1;
	DECLARE @cols NVARCHAR(MAX) = '';
	DECLARE @cnt_cols INT;
	DECLARE @Temp_Table NVARCHAR(max) = '';
	DECLARE @New_Table NVARCHAR(max) = '';
	DECLARE @vCreate_Sql1 NVARCHAR(max) = ''

	EXECUTE ('USE SAPBodsPi_ProfData_Prod');

	SELECT @TABLE_NAME = STAGING_TABLE
		,@EXTRACT_FILE = WD_EXTRACT_FILE
		,@ALTERNATE_KEY = ALTERNATE_KEY_COLUMN
	FROM SSISPi_FIN_Transformed_Data.FIN_EXTRACT_CONFIG
	WHERE EXTRACT_NAME = @EXTRACT
		AND IS_ACTIVE = 1;

	SET @Temp_Table = 'WD_EXTRACT_WT_' + @TABLE_NAME + '';
	SET @New_Table = 'WD_EXTRACT_' + @TABLE_NAME + '';

	------ Test that the entry in config table exists ------
	IF (
			@TABLE_NAME = ''
			OR @TABLE_NAME IS NULL
			)
	BEGIN
		RAISERROR (
				'The extract entry does not exist in the config table'
				,16
				,1
				)

		RETURN
	END

	------ Adding AK Column ------
	BEGIN
		/*
		DECLARE @cnt1 INT
		DECLARE @counter1 INT = 1

		DECLARE cursor_temp1 CURSOR
		FOR
		SELECT COLUMN_NAME
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_CATALOG = 'SAPBodsPi_ProfData_Prod'
			AND TABLE_SCHEMA = 'SSISPi_FIN_Transformed_Data'
			AND TABLE_NAME = @TABLE_NAME
			AND COLUMN_NAME NOT IN (
				'SOURCE_SYSTEM'
				,'LOAD_DATETIME'
				,'BATCH_ID'
				,'PACKAGE_NAME'
				,'ALTERNATE_KEY'
				)
		ORDER BY ORDINAL_POSITION;

		SELECT @cnt1 = count(*)
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE TABLE_CATALOG = 'SAPBodsPi_ProfData_Prod'
			AND TABLE_SCHEMA = 'SSISPi_FIN_Transformed_Data'
			AND TABLE_NAME = @TABLE_NAME
			AND COLUMN_NAME NOT IN (
				'SOURCE_SYSTEM'
				,'LOAD_DATETIME'
				,'BATCH_ID'
				,'PACKAGE_NAME'
				,'ALTERNATE_KEY'
				);

		OPEN cursor_temp1;

		WHILE (@counter1 <= @cnt1)
		BEGIN
			FETCH NEXT
			FROM cursor_temp1
			INTO @a;
			*/

		--TO UPDATE WD TABLES BASED ON CONFIG ENTRIES
		IF EXISTS (
				SELECT COLUMN_NAME
					,WD_VALUE
					,STG_VALUE
				FROM SSISPi_FIN_Transformed_Data.FIN_AUDIT_DATA_COMPARISON_CONFIG
				WHERE FUNCTIONALITY = 'REPLACE_DATA'
					AND TABLE_SOURCE = 'WORKDAY'
					AND Extract_Name = @EXTRACT
				)
		BEGIN
			DECLARE cursor_table_cols CURSOR
			FOR
			SELECT COLUMN_NAME
				,WD_VALUE
				,STG_VALUE
			FROM SSISPi_FIN_Transformed_Data.FIN_AUDIT_DATA_COMPARISON_CONFIG
			WHERE FUNCTIONALITY = 'REPLACE_DATA'
				AND TABLE_SOURCE = 'WORKDAY'
				AND Extract_Name = @EXTRACT;

			SELECT @cnt_cols = count(*)
			FROM SSISPi_FIN_Transformed_Data.FIN_AUDIT_DATA_COMPARISON_CONFIG
			WHERE FUNCTIONALITY = 'REPLACE_DATA'
				AND TABLE_SOURCE = 'WORKDAY'
				AND Extract_Name = @EXTRACT;

			OPEN cursor_table_cols;

			FETCH NEXT
			FROM cursor_table_cols
			INTO @COL_NAME
				,@WD_VALUE
				,@STG_VALUE;

			WHILE (@counter1 <= @cnt_cols)
			BEGIN
				SET @sql1 = 'update SSISPi_FIN_Transformed_Data.' + @Temp_Table + ' set [' + @COL_NAME + '] = replace(''' + @STG_VALUE + ''',''"'','''') where [' + @COL_NAME + '] = ''' + @WD_VALUE + '''';

				EXECUTE (@sql1)

				FETCH NEXT
				FROM cursor_table_cols
				INTO @COL_NAME
					,@WD_VALUE
					,@STG_VALUE;

				SET @counter1 = @counter1 + 1;
			END

			CLOSE cursor_table_cols;

			DEALLOCATE cursor_table_cols;
		END

		
		--TO UPDATE WD TABLES BASED ON CONFIG ENTRIES
		IF EXISTS (
				SELECT COLUMN_NAME
					,WD_VALUE
					,STG_VALUE
				FROM SSISPi_FIN_Transformed_Data.FIN_AUDIT_DATA_COMPARISON_CONFIG
				WHERE FUNCTIONALITY = 'REPLACE_FUNCTION'
					AND TABLE_SOURCE = 'WORKDAY'
					AND Extract_Name = @EXTRACT
				)
		BEGIN
			DECLARE cursor_table_cols CURSOR
			FOR
			SELECT COLUMN_NAME
				,WD_VALUE
				,STG_VALUE
			FROM SSISPi_FIN_Transformed_Data.FIN_AUDIT_DATA_COMPARISON_CONFIG
			WHERE FUNCTIONALITY = 'REPLACE_FUNCTION'
				AND TABLE_SOURCE = 'WORKDAY'
				AND Extract_Name = @EXTRACT;

			SELECT @cnt_cols = count(*)
			FROM SSISPi_FIN_Transformed_Data.FIN_AUDIT_DATA_COMPARISON_CONFIG
			WHERE FUNCTIONALITY = 'REPLACE_FUNCTION'
				AND TABLE_SOURCE = 'WORKDAY'
				AND Extract_Name = @EXTRACT;

			OPEN cursor_table_cols;

			FETCH NEXT
			FROM cursor_table_cols
			INTO @COL_NAME
				,@WD_VALUE
				,@STG_VALUE;

			WHILE (@counter2 <= @cnt_cols)
			BEGIN
				SET @sql1 = 'update SSISPi_FIN_Transformed_Data.' + @Temp_Table + ' set [' + @COL_NAME + '] = ' + @STG_VALUE + '';

				EXECUTE (@sql1)

				FETCH NEXT
				FROM cursor_table_cols
				INTO @COL_NAME
					,@WD_VALUE
					,@STG_VALUE;

				SET @counter2 = @counter2 + 1;
			END

			CLOSE cursor_table_cols;

			DEALLOCATE cursor_table_cols;
		END


		--DELETE RECORDS FROM WORKDAY TABLES WHICH ARE NOT REQUIRED
		IF EXISTS (
				SELECT COLUMN_NAME
					,WD_VALUE
					,STG_VALUE
				FROM SSISPi_FIN_Transformed_Data.FIN_AUDIT_DATA_COMPARISON_CONFIG
				WHERE FUNCTIONALITY = 'REMOVE_DATA'
					AND TABLE_SOURCE = 'WORKDAY'
					AND Extract_Name = @EXTRACT
				)
		BEGIN
			DECLARE cursor_table_cols CURSOR
			FOR
			SELECT COLUMN_NAME
				,WD_VALUE
				,STG_VALUE
			FROM SSISPi_FIN_Transformed_Data.FIN_AUDIT_DATA_COMPARISON_CONFIG
			WHERE FUNCTIONALITY = 'REMOVE_DATA'
				AND TABLE_SOURCE = 'WORKDAY'
				AND Extract_Name = @EXTRACT;

			SELECT @cnt_cols = count(*)
			FROM SSISPi_FIN_Transformed_Data.FIN_AUDIT_DATA_COMPARISON_CONFIG
			WHERE FUNCTIONALITY = 'REMOVE_DATA'
				AND TABLE_SOURCE = 'WORKDAY'
				AND Extract_Name = @EXTRACT;

			OPEN cursor_table_cols;

			FETCH NEXT
			FROM cursor_table_cols
			INTO @COL_NAME
				,@WD_VALUE
				,@STG_VALUE;

			WHILE (@counter3 <= @cnt_cols)
			BEGIN
				SET @sql1 = 'DELETE FROM SSISPi_FIN_Transformed_Data.' + @Temp_Table + ' WHERE ' + @WD_VALUE + '';

				EXEC (@sql1);

				FETCH NEXT
				FROM cursor_table_cols
				INTO @COL_NAME
					,@WD_VALUE
					,@STG_VALUE;

				SET @counter3 = @counter3 + 1;
			END

			CLOSE cursor_table_cols;

			DEALLOCATE cursor_table_cols;
		END


		--INSERT RECORDS INTO WORKDAY TABLE AS PER THE CONFIG TABLE
		IF EXISTS (
				SELECT COLUMN_NAME
					,WD_VALUE
					,STG_VALUE
				FROM SSISPi_FIN_Transformed_Data.FIN_AUDIT_DATA_COMPARISON_CONFIG
				WHERE FUNCTIONALITY = 'INSERT_DATA'
					AND TABLE_SOURCE = 'WORKDAY'
					AND Extract_Name = @EXTRACT
				)
		BEGIN
			SELECT @COL_NAME = COLUMN_NAME
				,@WD_VALUE = WD_VALUE
				,@STG_VALUE = STG_VALUE
			FROM SSISPi_FIN_Transformed_Data.FIN_AUDIT_DATA_COMPARISON_CONFIG
			WHERE FUNCTIONALITY = 'INSERT_DATA'
				AND TABLE_SOURCE = 'WORKDAY'
				AND Extract_Name = @EXTRACT;

			IF EXISTS (
					SELECT *
					FROM INFORMATION_SCHEMA.COLUMNS
					WHERE TABLE_CATALOG = 'SAPBodsPi_ProfData_Prod'
						AND TABLE_SCHEMA = 'SSISPi_FIN_Transformed_Data'
						AND TABLE_NAME = @New_Table
					)
			BEGIN
				SET @SQL_DROP_TABLE = 'drop table SSISPi_FIN_Transformed_Data.' + @New_Table + '';

				EXEC (@SQL_DROP_TABLE);
			END

			SET @sql5 = @WD_VALUE;

			EXEC (@sql5);

			SET @SQL_DROP_TABLE = 'drop table SSISPi_FIN_Transformed_Data.' + @Temp_Table + '';

			EXEC (@SQL_DROP_TABLE);
		END

		IF NOT EXISTS (
				SELECT COLUMN_NAME
					,WD_VALUE
					,STG_VALUE
				FROM SSISPi_FIN_Transformed_Data.FIN_AUDIT_DATA_COMPARISON_CONFIG
				WHERE FUNCTIONALITY = 'INSERT_DATA'
					AND TABLE_SOURCE = 'WORKDAY'
					AND Extract_Name = @EXTRACT
				)
		BEGIN
			IF EXISTS (
					SELECT *
					FROM INFORMATION_SCHEMA.COLUMNS
					WHERE TABLE_CATALOG = 'SAPBodsPi_ProfData_Prod'
						AND TABLE_SCHEMA = 'SSISPi_FIN_Transformed_Data'
						AND TABLE_NAME = @New_Table
					)
			BEGIN
			SET @SQL_DROP_TABLE = 'drop table SSISPi_FIN_Transformed_Data.' + @New_Table + '';

			EXEC (@SQL_DROP_TABLE);
			END

			SET @vCreate_Sql1 = 'SELECT * INTO SSISPi_FIN_Transformed_Data.' + @New_Table + ' FROM SSISPi_FIN_Transformed_Data.' + @Temp_Table + '';

			EXECUTE (@vCreate_Sql1);

			SET @SQL_DROP_TABLE = 'drop table SSISPi_FIN_Transformed_Data.' + @Temp_Table + '';

			EXEC (@SQL_DROP_TABLE);
		END
		
	END

	EXECUTE ('ALTER TABLE SSISPi_FIN_Transformed_Data.' + @New_Table + ' ADD ALTERNATE_KEY nvarchar(500)');

	
	------ Adding Alternate Key ------
	BEGIN
		DECLARE @cnt2 INT
		DECLARE @counter4 INT = 1

		DECLARE cursor_temp2 CURSOR
		FOR
		SELECT data
		FROM dbo.Split(@ALTERNATE_KEY, ',');

		SELECT @cnt2 = max(id)
		FROM SSISPi_FIN_Transformed_Data.Split(@ALTERNATE_KEY, ',');

		OPEN cursor_temp2;

		WHILE (@counter4 <= @cnt2)
		BEGIN
			FETCH NEXT
			FROM cursor_temp2
			INTO @b

			SET @sql2 = 'update SSISPi_FIN_Transformed_Data.' + @New_Table + ' set ALTERNATE_KEY = concat(ALTERNATE_KEY,[' + @b + '],''='')';

			EXECUTE (@sql2);

			SET @counter4 = @counter4 + 1;
		END

		CLOSE cursor_temp2;

		DEALLOCATE cursor_temp2;
	END

	SET @sql3 = 'update SSISPi_FIN_Transformed_Data.' + @New_Table + ' set ALTERNATE_KEY = REVERSE(REPLACE(STUFF(reverse(ALTERNATE_KEY),charindex(''='',reverse(ALTERNATE_KEY)),1,''~''),''~'',''''))'

	EXEC (@sql3);

	SET @sql4 = 'update SSISPi_FIN_Transformed_Data.' + @New_Table + ' set ALTERNATE_KEY = REPLACE(ALTERNATE_KEY,''='',''~|'')'

	EXEC (@sql4);
	
END
GO


