USE [SAPBodsPi_ProfData_Prod]
GO

/****** Object:  StoredProcedure [SSISPi_HR_Transformed_Data].[HR_DELTA_LOAD_NEW_RECORDS_PROC]    Script Date: 17/06/2021 3:20:35 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




CREATE PROCEDURE [SSISPi_HR_Transformed_Data].[HR_DELTA_LOAD_NEW_RECORDS_PROC] @wd_extract_name NVARCHAR(200) = NULL
AS
DECLARE @TABLE_NAME NVARCHAR(MAX) = '';
DECLARE @a VARCHAR(max);
DECLARE @b VARCHAR(max);
DECLARE @c VARCHAR(max);
DECLARE @d VARCHAR(max);
DECLARE @e VARCHAR(max);
DECLARE @f VARCHAR(max);
DECLARE @cnt INT;
DECLARE @counter INT = 1;
DECLARE @vCreate_Sql NVARCHAR(max) = ''


DECLARE cursor_temp CURSOR
FOR
SELECT CASE WHEN CONCAT (CASE WHEN SUBSTRING(SUBJECT_AREA, 0, 4) = 'HR' THEN 'HR_STG_'
								 WHEN SUBSTRING(SUBJECT_AREA, 0, 4)='HR' THEN 'HR_STG_'
								 WHEN SUBSTRING(SUBJECT_AREA, 0, 4)= 'PRC' THEN 'PRC_STG_' ELSE 'HR_STG_' END
							,LEFT(EXTRACT_NAME, LEN(EXTRACT_NAME)-3) ) = 'HR_STG_ACCOUNTING_JOURNAL_MONTH_END_VNM_ADJUSTMENT' THEN 'HR_STG_ACCOUNTING_JOURNAL_MONTH_END_ADJUSTMENT'
			   ELSE CONCAT (CASE WHEN SUBSTRING(SUBJECT_AREA, 0, 4) = 'HR' THEN 'HR_STG_'
								 WHEN SUBSTRING(SUBJECT_AREA, 0, 4)='HR' THEN 'HR_STG_'
								 WHEN SUBSTRING(SUBJECT_AREA, 0, 4)= 'PRC' THEN 'PRC_STG_' ELSE 'HR_STG_' END
							,LEFT(EXTRACT_NAME, LEN(EXTRACT_NAME)-3)) END STAGING_TABLE
							,CASE WHEN CHARINDEX(',', ALTERNATE_KEY_COLUMN_NAME) > 0 THEN CONCAT ('CONCAT(' ,REPLACE(ALTERNATE_KEY_COLUMN_NAME, ',', ',''~|'','),')') ELSE ALTERNATE_KEY_COLUMN_NAME END ALTERNATE_KEY_COLUMN
							,REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(SUBJECT_AREA,'AU','SAP'),'VN','VN'),'-',''),'_',''),'HR',''),'PRC',''),'HR','') SOURCE_SYSTEM 
							,SUBJECT_AREA
							,ALTERNATE_KEY_COLUMN_NAME
							,EXTRACT_NAME
FROM SSISPi_HR_Transformed_Data.HR_AUDIT_MAP_EXTRACT_AK
WHERE IS_INCREMENTAL = 1
AND EXTRACT_NAME = ISNULL(@wd_extract_name, EXTRACT_NAME);

SELECT @cnt = count(*)
FROM SSISPi_HR_Transformed_Data.HR_AUDIT_MAP_EXTRACT_AK
WHERE IS_INCREMENTAL = 1
	AND EXTRACT_NAME = ISNULL(@wd_extract_name, EXTRACT_NAME);

OPEN cursor_temp;

FETCH NEXT
FROM cursor_temp
INTO @a
	,@b
	,@c
	,@d
	,@e
	,@f;

WHILE (@counter < @cnt)
BEGIN
	SET @vCreate_Sql = @vCreate_Sql + 'SELECT  ''' + @d + ''' AS SUBJECT_AREA, ''' + @c + ''' AS SOURCE_SYSTEM, ''' + @f + ''' as EXTRACT_NAME, ''' + @e + ''' AS ALTERNATE_KEY, T1.ALTERNATE_KEY AS ALTERNATE_KEY_VALUE, ''New Record'' AS REC_TYPE,
			T1.BATCH_ID, T1.LOAD_DATETIME, T2.BATCH_ID DEV_BATCH_ID
            FROM (select *, ' + @b + ' AS AK from SSISPi_HR_Transformed_Data.' + @a + ' WHERE SOURCE_SYSTEM=''' + @c + ''') T1
            LEFT JOIN (select a.*,' + @b + ' AS AK from SSISPi_HR_Transformed_Data_dev.' + @a + ' a WHERE SOURCE_SYSTEM=''' + @c + ''') T2  ON T1.AK = T2.AK
            WHERE T2.ALTERNATE_KEY is NULL';
	SET @vCreate_Sql = @vCreate_Sql + ' union ';

	FETCH NEXT
	FROM cursor_temp
	INTO @a
		,@b
		,@c
		,@d
		,@e
		,@f;

	SET @counter = @counter + 1;
END

BEGIN
	SET @vCreate_Sql = @vCreate_Sql + 'SELECT  ''' + @d + ''' AS SUBJECT_AREA, ''' + @c + ''' AS SOURCE_SYSTEM, ''' + @f + ''' as EXTRACT_NAME, ''' + @e + ''' AS ALTERNATE_KEY, T1.ALTERNATE_KEY AS ALTERNATE_KEY_VALUE, ''New Record'' AS REC_TYPE,
			T1.BATCH_ID, T1.LOAD_DATETIME, T2.BATCH_ID DEV_BATCH_ID
            FROM (select *, ' + @b + ' AS AK from SSISPi_HR_Transformed_Data.' + @a + ' WHERE SOURCE_SYSTEM=''' + @c + ''') T1
            LEFT JOIN (select a.*,' + @b + ' AS AK from SSISPi_HR_Transformed_Data_dev.' + @a + ' a WHERE SOURCE_SYSTEM=''' + @c + ''') T2  ON T1.AK = T2.AK
            WHERE T2.ALTERNATE_KEY is NULL';
END

CLOSE cursor_temp;

DEALLOCATE cursor_temp;


INSERT INTO SSISPi_HR_Transformed_Data.HR_DELTA_LOAD_NEW_RECORDS
EXEC (@vCreate_Sql);


GO


