USE [SAPBodsPi_ProfData_Prod]
GO

/****** Object:  Table [SSISPi_HR_Transformed_Data].[HR_DATA_CONVERSION_CUSTOM_SOLUTION_REPORT_3]    Script Date: 17/06/2021 3:28:06 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [SSISPi_HR_Transformed_Data].[HR_DATA_CONVERSION_CUSTOM_SOLUTION_REPORT_3](
	[SUBJECT_AREA] [nvarchar](500) NULL,
	[SOURCE_SYSTEM] [nvarchar](500) NULL,
	[EXTRACT_NAME] [nvarchar](500) NULL,
	[ALTERNATE_KEY] [nvarchar](500) NULL,
	[ALTERNATE_KEY_VALUE] [nvarchar](max) NULL,
	[COLUMN_NAME] [nvarchar](500) NULL,
	[VALUE_IN_STAGE] [nvarchar](max) NULL,
	[VALUE_IN_WORKDAY] [nvarchar](max) NULL,
	[ERROR_DESCRIPTION] [nvarchar](500) NULL,
	[BATCH_ID] [int] NULL,
	[LOAD_DATETIME] [datetime] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO


