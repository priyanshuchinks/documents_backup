USE [SAPBodsPi_ProfData_Prod]
GO

/****** Object:  Table [SSISPi_FIN_Transformed_Data_Dev].[FIN_AUDIT_ETLLOADINFO]    Script Date: 17/06/2021 3:22:19 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [SSISPi_FIN_Transformed_Data_Dev].[FIN_AUDIT_ETLLOADINFO](
	[BATCH_ID] [bigint] IDENTITY(1,1) NOT NULL,
	[LOAD_ID] [bigint] NOT NULL,
	[ETL_PHASE] [nvarchar](50) NULL,
	[PACKAGE_NAME] [nvarchar](255) NULL,
	[STATUS] [nvarchar](20) NULL,
	[MESSAGE] [nvarchar](1000) NULL,
	[PACKAGE_ID] [nvarchar](100) NULL,
	[PACKAGE_VERSION] [varchar](100) NULL,
	[START_TIME] [datetime] NULL,
	[END_TIME] [datetime] NULL,
	[EXECUTED_BY] [nvarchar](255) NOT NULL
) ON [PRIMARY]
GO


