package com.telstra.ccm.crl

import java.util

import com.telstra.audit.service.AuditService
import com.telstra.ccm.controller.GetAttributes
import com.telstra.ccm.utils.AppUtils._
import org.apache.spark.sql.{DataFrame, Row, SQLContext, SaveMode}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.sql.functions._
import org.slf4j.LoggerFactory
import org.apache.spark.sql.SaveMode
import com.telstra.ccm.utils._
import org.apache.spark.SparkContext

import scala.collection.mutable

class SourceValidationRules extends Serializable {
  val sc = new SparkContext()
  var inputDF:DataFrame=null
  val sqlContext = new org.apache.spark.sql.hive.HiveContext(sc)
  var sourceDF = sqlContext.sql("select * from datalab_dqrdac_dev.valid_src").withColumn("tmp_failure_rule_id", lit(null).cast("String"))

  var ruleResult=sourcevalidationrules405(sourceDF, sqlContext: HiveContext, null, "", "", new Integer(1), new Integer(123) ).asInstanceOf[DataFrame]
  sourceDF=ruleResult

  def sourcevalidationrules400(inputDF: DataFrame, sqlContext: HiveContext, appId: String, sourceSystem: String, tableName: String, ruleId: Int, auditID: Int): DataFrame = {
    try {
      //      Logger.info(s"Executing :: matchRule$ruleId")
      //    AuditService.insertAuditEntry(appId,sourceSystem,tableName,ruleId)
      var temp = inputDF.withColumn("rule400", when((col("is_online1") === true) && (col("is_online2") === false), true).otherwise(false)).withColumn("failure_rule_id", when((col("rule400") === true) && (col("tmp_failure_rule_id").equalTo("") || col("tmp_failure_rule_id").isNull), "rule400")).drop(col("tmp_failure_rule_id")).withColumnRenamed("failure_rule_id", "tmp_failure_rule_id")
      temp
    } catch {
      case ex: Exception => {
        //    Logger.error(s"Error while executing - matchRule$ruleId")
        //  AuditService.updateFailureEntry(appId, sourceSystem, tableName, ruleId, ex.getMessage)
        throw ex
      }
    }
  }


  def sourcevalidationrules401(inputDF: DataFrame, sqlContext: HiveContext, appId: String, sourceSystem: String, tableName: String, ruleId: Int, auditID: Int): DataFrame = {
    try {
      // Logger.info(s"Executing :: matchRule$ruleId")
      //AuditService.insertAuditEntry(appId,sourceSystem,tableName,ruleId)
      var temp = inputDF.withColumn("rule401", when(col("X_COLLECTIONS_FLG1").equalTo(true), true).otherwise(false)).withColumn("failure_rule_id", when(col("rule401") === true && col("tmp_failure_rule_id").isNull, "rule401").otherwise(col("tmp_failure_rule_id"))).drop(col("tmp_failure_rule_id")).withColumnRenamed("failure_rule_id", "tmp_failure_rule_id")
      temp
    } catch {
      case ex: Exception => {
        //Logger.error(s"Error while executing - matchRule$ruleId")
        //AuditService.updateFailureEntry(appId, sourceSystem, tableName, ruleId, ex.getMessage)
        throw ex
      }
    }
  }


  def sourcevalidationrules402(inputDF:DataFrame,sqlContext:HiveContext,appId:String,sourceSystem:String,tableName:String,ruleId:Int,auditID:Int): DataFrame ={
    try {
      //Logger.info(s"Executing :: matchRule$ruleId")
      //AuditService.insertAuditEntry(appId,sourceSystem,tableName,ruleId)

       var temp = inputDF.withColumn("rule402",when(col("cust_row_id1") === col("cust_row_id2") && col("relation_type_cd_rank1").lt(col("relation_type_cd_rank2")),true).otherwise(false)).withColumn("failure_rule_id",when((col("rule402").equalTo(true)) && ( col("tmp_failure_rule_id").isNull),"rule402").otherwise(col("tmp_failure_rule_id"))).drop(col("tmp_failure_rule_id")).withColumnRenamed("failure_rule_id","tmp_failure_rule_id")
      //temp.filter(col("con_row_id1") === "1-1KCL5HM").show()
       temp

    }catch{
      case ex:Exception=>{
        //Logger.error(s"Error while executing - matchRule$ruleId")
        //AuditService.updateFailureEntry(appId, sourceSystem, tableName, ruleId, ex.getMessage)
        throw ex
      }
    }
  }


  def sourcevalidationrules403(inputDF:DataFrame,sqlContext:HiveContext,appId:String,sourceSystem:String,tableName:String,ruleId:Int,auditID:Int): DataFrame = {
    try {
//      Logger.info(s"Executing :: matchRule$ruleId")
//      AuditService.insertAuditEntry(appId,sourceSystem,tableName,ruleId)
      var temp = inputDF.withColumn("rule403" ,when(col("is_inflight_order1") === true ,true).otherwise(false)).withColumn("failure_rule_id",when((col("rule403").equalTo(true) && col("tmp_failure_rule_id").isNull ),"rule403").otherwise(col("tmp_failure_rule_id"))).drop(col("tmp_failure_rule_id")).withColumnRenamed("failure_rule_id","tmp_failure_rule_id")
      temp
    }catch{
      case ex:Exception=>{
//        Logger.error(s"Error while executing - matchRule$ruleId")
//        AuditService.updateFailureEntry(appId, sourceSystem, tableName, ruleId, ex.getMessage)
        throw ex
      }
    }
  }

  def sourcevalidationrules404(inputDF:DataFrame,sqlContext:HiveContext,appId:String,sourceSystem:String,tableName:String,ruleId:Int,auditID:Int): DataFrame ={
    try {
//      Logger.info(s"Executing :: matchRule$ruleId")
//      AuditService.insertAuditEntry(appId,sourceSystem,tableName,ruleId)
      var temp = inputDF.withColumn("rule404" ,when( (col("BPay1") === true),true).otherwise(false)).withColumn("failure_rule_id",when( ( (col("rule404").equalTo(true)) && ( col("tmp_failure_rule_id").isNull) ),"rule404").otherwise(col("tmp_failure_rule_id"))).drop(col("tmp_failure_rule_id")).withColumnRenamed("failure_rule_id","tmp_failure_rule_id")
      temp
    }catch{
      case ex:Exception=>{
//        Logger.error(s"Error while executing - matchRule$ruleId")
//        AuditService.updateFailureEntry(appId, sourceSystem, tableName, ruleId, ex.getMessage)
        throw ex
      }
    }
  }

  def sourcevalidationrules405(inputDF:DataFrame,sqlContext:HiveContext,appId:String,sourceSystem:String,tableName:String,ruleId:Int,auditID:Int): DataFrame ={
    try {
//      Logger.info(s"Executing :: matchRule$ruleId")
//      AuditService.insertAuditEntry(appId,sourceSystem,tableName,ruleId)
      var temp = inputDF.withColumn("rule405" ,when( (col("euid1") === true) && (col("euid2") === false or col("euid2").isNull),true).otherwise(false)).withColumn("failure_rule_id",when( ( (col("rule405").equalTo(true)) && ( col("tmp_failure_rule_id").isNull) ),"rule405").otherwise(col("tmp_failure_rule_id"))).drop(col("tmp_failure_rule_id"))
      // t2.write.format("orc").mode(SaveMode.Overwrite).saveAsTable("datalab_dqrdac_dev.ST_temp_data")

      //inputDF.write.mode(SaveMode.Overwrite).format("ORC").saveAsTable("datalab_dqrdac_dev.valid_src_rules")
      temp
    }catch{
      case ex:Exception=>{
//        Logger.error(s"Error while executing - matchRule$ruleId")
//        AuditService.updateFailureEntry(appId, sourceSystem, tableName, ruleId, ex.getMessage)
        throw ex
      }
    }
  }

  def getMultipleTargetSets(inputDF:DataFrame, sqlContext:HiveContext, appId:String, sourceSystem:String, tableName:String, ruleId:Int, auditID:Int): DataFrame ={
    try {
      Logger.info(s"Executing :: matchRule$ruleId")
      AuditService.insertAuditEntry(appId,sourceSystem,tableName,ruleId)

      val inputDF = sqlContext.sql("select * from datalab_dqrdac_dev.valid_src_rules")
      val notSourceCon = inputDF.withColumn("dummyY", when(col("failure_rule_id").isNull, 1).otherwise(0)).groupBy(col("con_row_id1")).agg(sum(col("dummyY")).as("cnt")).where("cnt=0").select("con_row_id1")
      val notTargetCon = inputDF.withColumn("dummyY", when(col("failure_rule_id").isNull, 1).otherwise(0)).groupBy(col("con_row_id2")).agg(sum(col("dummyY")).as("cnt")).where("cnt=0").select("con_row_id2")
      val neitherSourceTarget = notSourceCon.intersect(notTargetCon).collect().distinct.map(_ (0)).toSeq
      inputDF.persist()
      val tempTarget = inputDF.withColumn("flg",when(col("failure_rule_id").isNotNull,1).otherwise(0)).select(col("u_set_id1"),col("con_row_id1"),col("flg")).dropDuplicates().filter(not(col("con_row_id1").isin(neitherSourceTarget  : _*))).groupBy(col("u_set_id1")).agg(sum(col("flg")).as("flg"))
      tempTarget.persist()
      var singleTargetList = tempTarget.select("u_set_id1","flg").where("flg = 1")


      var MultipleTargetList = tempTarget.select("u_set_id1","flg").where("flg = 0 or flg > 1")


      var singleTargetSets = inputDF.join(singleTargetList,Seq("u_set_id1"))
      var MultipleTargetSets = inputDF.filter(not(col("con_row_id1").isin(neitherSourceTarget  : _*))).join(MultipleTargetList,Seq("u_set_id1"))
      MultipleTargetSets.persist()
      MultipleTargetSets.write.mode(SaveMode.Overwrite).format("ORC").saveAsTable("datalab_dqrdac_dev.valid_target_contendors")

      /**Dishant Code startes */
//      var t3 = inputDF.filter(col("failure_rule_id").isNotNull and col("con_row_id1").isin(neitherSourceTarget  : _*)).groupBy(col("con_row_id1"),col("u_set_id1")).agg(collect_list(col("con_row_id2")))
//      var t4 = t3.groupBy(col("u_set_id")).agg(count("*") === 1).select("u_set_id1").collect.map(_.getLong(0)).toList
//      var singleTargetSets = t3.where(col("u_set_id").isin(t4 : _*)).select(col("u_set_id1"),col("con_row_id1"))
//      singleTargetSets.registerTempTable("datalab_dqrdac_dev.temp_tbl_single_target_sets")
//      var multipleTargetSets = t3.where(not(col("u_set_id").isin(t4 : _*))).select(col("u_set_id1"),col("con_row_id1"))
      inputDF
    }catch{
      case ex:Exception=>{
        Logger.error(s"Error while executing - matchRule$ruleId")
        AuditService.updateFailureEntry(appId, sourceSystem, tableName, ruleId, ex.getMessage)
        throw ex
      }
    }
  }

}
