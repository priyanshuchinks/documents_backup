package com.telstra.ccm.crl

import com.telstra.audit.service.AuditService
import org.apache.spark.SparkContext
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.functions.{col, when}
import org.apache.spark.sql.hive.HiveContext
import org.slf4j.LoggerFactory

class TargetValidationRules extends Serializable {

  private val Logger = LoggerFactory.getLogger(classOf[SourceValidationRules].getName)
  val sc = new SparkContext()
  val hiveContext = new org.apache.spark.sql.hive.HiveContext(sc)

  import hiveContext.implicits._
  val sc = new SparkContext()
  var inputDF:DataFrame=null
  val sqlContext = new org.apache.spark.sql.hive.HiveContext(sc)

  var sourceDF =MultipleTargetSets
    //sqlContext.sql("select distinct u_set_id1, con_row_id1,is_asset_curr1, is_bill_curr1,BPay1, euid1,  src_field_type1, src_field1,  valid_dl1 no_of_customers1, last_upd1, x_last_dvs_verify1, is_linked_company_org1, no_valid_phone_email1, cust_row_id1, relation_type_cd_rank1 from datalab_dqrdac_dev.valid_target_contendors")
  var ruleResult=targetValidationRule500(sourceDF, sqlContext: HiveContext, null, "", "", new Integer(1), new Integer(123) ).asInstanceOf[DataFrame]
  sourceDF=ruleResult

  def targetValidationRule500(inputDF: DataFrame, sqlContext: HiveContext, appId: String, sourceSystem: String, tableName: String, ruleId: Int, auditID: Int): DataFrame = {
    try {
//      Logger.info(s"Executing :: matchRule$ruleId")
//      AuditService.insertAuditEntry(appId, sourceSystem, tableName, ruleId)
      val w = Window.partitionBy(col("u_set_id1")).orderBy(col("no_of_customers1") desc)
      var t = inputDF.withColumn("rank_500", dense_rank().over(w))
      t.persist()

      var foundTargetSets = t.where("rank_500 = 1").groupBy(col("u_set_id1")).agg(count("*").as("cnt"),min("con_row_id1")).where("cnt = 1")

      var filteredSetsForNextRule = t.select(col("u_set_id1")).except(foundTargetSets.select("u_set_id1")).collect().map(_.getLong(0)).toList
      return inputDF.where(col("u_set_id1").isin(filteredSetsForNextRule: _*))

    }catch{
      case ex: Exception => {
//        Logger.error(s"Error while executing - matchRule$ruleId")
//        AuditService.updateFailureEntry(appId, sourceSystem, tableName, ruleId, ex.getMessage)
        throw ex
      }
    }
  }

  def targetValidationRule501(inputDF: DataFrame, sqlContext: HiveContext, appId: String, sourceSystem: String, tableName: String, ruleId: Int, auditID: Int): DataFrame = {
    try {
//      Logger.info(s"Executing :: matchRule$ruleId")
//      AuditService.insertAuditEntry(appId, sourceSystem, tableName, ruleId)
      var t = inputDF.withColumn("rank_501", when(col("is_valid_dob1") === true, 1).otherwise(2))
      t.persist()
      var foundTargetSets = t.where("rank_501 = 1").groupBy(col("u_set_id1")).agg(count("*").as("cnt")).where("cnt = 1")

      var filteredSetsForNextRule = t.select(col("u_set_id1")).except(foundTargetSets.select("u_set_id1")).collect().map(_.getLong(0)).toList
      return inputDF.where(col("u_set_id1").isin(filteredSetsForNextRule: _*))

    }catch{
      case ex: Exception => {
//        Logger.error(s"Error while executing - matchRule$ruleId")
//        AuditService.updateFailureEntry(appId, sourceSystem, tableName, ruleId, ex.getMessage)
        throw ex
      }
    }
  }


  def targetValidationRule502(inputDF: DataFrame, sqlContext: HiveContext, appId: String, sourceSystem: String, tableName: String, ruleId: Int, auditID: Int): DataFrame = {
    try {
//      Logger.info(s"Executing :: matchRule$ruleId")
//      AuditService.insertAuditEntry(appId, sourceSystem, tableName, ruleId)
      val w = Window.partitionBy(col("u_set_id1")).orderBy(col("x_last_dvs_verify1") desc)
      var t = inputDF.withColumn("rank_502", dense_rank().over(w))
      t.persist()
      t.persist()
      var foundTargetSets = t.where("rank_502 = 1").groupBy(col("u_set_id1")).agg(count("*").as("cnt")).where("cnt = 1")
      var filteredSetsForNextRule = t.select(col("u_set_id1")).except(foundTargetSets.select("u_set_id1")).collect().map(_.getLong(0)).toList
      return inputDF.where(col("u_set_id1").isin(filteredSetsForNextRule: _*))
    }catch{
      case ex: Exception => {
//        Logger.error(s"Error while executing - matchRule$ruleId")
//        AuditService.updateFailureEntry(appId, sourceSystem, tableName, ruleId, ex.getMessage)
        throw ex
      }
    }
  }


  def targetValidationRule503(inputDF: DataFrame, sqlContext: HiveContext, appId: String, sourceSystem: String, tableName: String, ruleId: Int, auditID: Int): DataFrame = {
    try {
//      Logger.info(s"Executing :: matchRule$ruleId")
//      AuditService.insertAuditEntry(appId, sourceSystem, tableName, ruleId)
      var t = inputDF.withColumn("rank_503", when(col("valid_dl") === true, 1).otherwise(2))
      t.persist()
      t.persist()
      var foundTargetSets = t.where("rank_503 = 1").groupBy(col("u_set_id1")).agg(count("*").as("cnt")).where("cnt = 1")
      var filteredSetsForNextRule = t.select(col("u_set_id1")).except(foundTargetSets.select("u_set_id1")).collect().map(_.getLong(0)).toList
      return inputDF.where(col("u_set_id").isin(filteredSetsForNextRule: _*))
    }catch{
      case ex: Exception => {
//        Logger.error(s"Error while executing - matchRule$ruleId")
//        AuditService.updateFailureEntry(appId, sourceSystem, tableName, ruleId, ex.getMessage)
        throw ex
      }
    }
  }


  def targetValidationRule504(inputDF: DataFrame, sqlContext: HiveContext, appId: String, sourceSystem: String, tableName: String, ruleId: Int, auditID: Int): DataFrame = {
    try {
//      Logger.info(s"Executing :: matchRule$ruleId")
//      AuditService.insertAuditEntry(appId, sourceSystem, tableName, ruleId)
      val w = Window.partitionBy(col("u_set_id")).orderBy(col("no_valid_phone_email1") desc)
      var t = inputDF.withColumn("rank_504", dense_rank().over(w))
      t.persist()
      var foundTargetSets = t.where("rank_504 = 1").groupBy(col("u_set_id1")).agg(count("*").as("cnt")).where("cnt = 1")
      var filteredSetsForNextRule = t.select(col("u_set_id1")).except(foundTargetSets.select("u_set_id1")).collect().map(_.getLong(0)).toList
      return inputDF.where(col("u_set_id1").isin(filteredSetsForNextRule: _*))

    }catch{
      case ex: Exception => {
//        Logger.error(s"Error while executing - matchRule$ruleId")
//        AuditService.updateFailureEntry(appId, sourceSystem, tableName, ruleId, ex.getMessage)
        throw ex
      }
    }
  }
////////////////////////////

  def targetValidationRule505(inputDF: DataFrame, sqlContext: HiveContext, appId: String, sourceSystem: String, tableName: String, ruleId: Int, auditID: Int): DataFrame = {
    try {
      Logger.info(s"Executing :: matchRule$ruleId")
      AuditService.insertAuditEntry(appId, sourceSystem, tableName, ruleId)
      var t = inputDF.withColumn("rank_505", when(col("is_integrated_invoice") === true, 1).otherwise(2))
      t.persist()
      var foundTargetSets = t.where("rank_505 = 1").groupBy(col("u_set_id")).agg(count("*").as("cnt")).where("cnt = 1")
      //t.where("rank_500 != 1").withColumn("FailureID",col("ruleId"))
      var filteredSetsForNextRule = t.select(col("u_set_id")).except(foundTargetSets.select("u_set_id")).collect().map(_.getLong(0)).toList
      return inputDF.where(col("u_set_id").isin(filteredSetsForNextRule: _*))

    }catch{
      case ex: Exception => {
        Logger.error(s"Error while executing - matchRule$ruleId")
        AuditService.updateFailureEntry(appId, sourceSystem, tableName, ruleId, ex.getMessage)
        throw ex
      }
    }
  }

  def targetValidationRule506(inputDF: DataFrame, sqlContext: HiveContext, appId: String, sourceSystem: String, tableName: String, ruleId: Int, auditID: Int): DataFrame = {
    try {
      Logger.info(s"Executing :: matchRule$ruleId")
      AuditService.insertAuditEntry(appId, sourceSystem, tableName, ruleId)
      var t = inputDF.withColumn("rank_506", when(col("is_linked_company_org1") === true, 1).otherwise(2))
      t.persist()
      var foundTargetSets = t.where("rank_506 = 1").groupBy(col("u_set_id1")).agg(count("*").as("cnt")).where("cnt = 1")
      //t.where("rank_500 != 1").withColumn("FailureID",col("ruleId"))
      var filteredSetsForNextRule = t.select(col("u_set_id1")).except(foundTargetSets.select("u_set_id1")).collect().map(_.getLong(0)).toList
      return inputDF.where(col("u_set_id1").isin(filteredSetsForNextRule: _*))

    }catch{
      case ex: Exception => {
        Logger.error(s"Error while executing - matchRule$ruleId")
        AuditService.updateFailureEntry(appId, sourceSystem, tableName, ruleId, ex.getMessage)
        throw ex
      }
    }
  }

  def targetValidationRule507(inputDF: DataFrame, sqlContext: HiveContext, appId: String, sourceSystem: String, tableName: String, ruleId: Int, auditID: Int): DataFrame = {
    try {
      Logger.info(s"Executing :: matchRule$ruleId")
      AuditService.insertAuditEntry(appId, sourceSystem, tableName, ruleId)
      var t = inputDF.withColumn("rank_507", when(col("is_curr_asset1") === true, 1).otherwise(2))
      t.persist()
      var foundTargetSets = t.where("rank_507 = 1").groupBy(col("u_set_id1")).agg(count("*").as("cnt")).where("cnt = 1")
      //t.where("rank_500 != 1").withColumn("FailureID",col("ruleId"))
      var filteredSetsForNextRule = t.select(col("u_set_id1")).except(foundTargetSets.select("u_set_id1")).collect().map(_.getLong(0)).toList
      return inputDF.where(col("u_set_id1").isin(filteredSetsForNextRule: _*))

    }catch{
      case ex: Exception => {
        Logger.error(s"Error while executing - matchRule$ruleId")
        AuditService.updateFailureEntry(appId, sourceSystem, tableName, ruleId, ex.getMessage)
        throw ex
      }
    }
  }

  def targetValidationRule508(inputDF: DataFrame, sqlContext: HiveContext, appId: String, sourceSystem: String, tableName: String, ruleId: Int, auditID: Int): DataFrame = {
    try {
      Logger.info(s"Executing :: matchRule$ruleId")
      AuditService.insertAuditEntry(appId, sourceSystem, tableName, ruleId)
      var t = inputDF.withColumn("rank_508", when(col("is_curr_bill1") === true, 1).otherwise(2))
      t.persist()
      var foundTargetSets = t.where("rank_508 = 1").groupBy(col("u_set_id1")).agg(count("*").as("cnt"),collect_list("con_row_id1")).where("cnt = 1")
      //t.where("rank_500 != 1").withColumn("FailureID",col("ruleId"))
      var filteredSetsForNextRule = t.select(col("u_set_id1")).except(foundTargetSets.select("u_set_id1")).collect().map(_.getLong(0)).toList
      return inputDF.where(col("u_set_id1").isin(filteredSetsForNextRule: _*))

    }catch{
      case ex: Exception => {
        Logger.error(s"Error while executing - matchRule$ruleId")
        AuditService.updateFailureEntry(appId, sourceSystem, tableName, ruleId, ex.getMessage)
        throw ex
      }
    }
  }

  def targetValidationRule509(inputDF: DataFrame, sqlContext: HiveContext, appId: String, sourceSystem: String, tableName: String, ruleId: Int, auditID: Int): DataFrame = {
    try {
      Logger.info(s"Executing :: matchRule$ruleId")
      AuditService.insertAuditEntry(appId, sourceSystem, tableName, ruleId)
      val w = Window.partitionBy(col("u_set_id1")).orderBy(col("last_upd1") desc)
      var t = inputDF.withColumn("rank_509", dense_rank().over(w))
      t.persist()
      var foundTargetSets = t.where("rank_509 = 1").groupBy(col("u_set_id1")).agg(count("*").as("cnt")).where("cnt = 1")
      var filteredSetsForNextRule = t.select(col("u_set_id1")).except(foundTargetSets.select("u_set_id1")).collect().map(_.getLong(0)).toList
      return inputDF.where(col("u_set_id1").isin(filteredSetsForNextRule: _*))
    }catch{
      case ex: Exception => {
        Logger.error(s"Error while executing - matchRule$ruleId")
        AuditService.updateFailureEntry(appId, sourceSystem, tableName, ruleId, ex.getMessage)
        throw ex
      }
    }
  }

  def targetValidationRule510(inputDF: DataFrame, sqlContext: HiveContext, appId: String, sourceSystem: String, tableName: String, ruleId: Int, auditID: Int): DataFrame = {
    try {
      Logger.info(s"Executing :: matchRule$ruleId")
      AuditService.insertAuditEntry(appId, sourceSystem, tableName, ruleId)
      val w = Window.partitionBy(col("u_set_id1")).orderBy(col("con_row_id1") desc)
      var t = inputDF.withColumn("rank_510", dense_rank().over(w))
      t.persist()
      var foundTargetSets = t.where("rank_510 = 1").groupBy(col("u_set_id1")).agg(count("*").as("cnt")).where("cnt = 1")
      var filteredSetsForNextRule = t.select(col("u_set_id1")).except(foundTargetSets.select("u_set_id1")).collect().map(_.getLong(0)).toList
      return inputDF.where(col("u_set_id1").isin(filteredSetsForNextRule: _*))
    }catch {
      case ex: Exception => {
        Logger.error(s"Error while executing - matchRule$ruleId")
        AuditService.updateFailureEntry(appId, sourceSystem, tableName, ruleId, ex.getMessage)
        throw ex
      }
    }
  }


  def tagSourceTarget(inputDF: DataFrame, crossMatrixDF: DataFrame,sqlContext: HiveContext, appId: String, sourceSystem: String, tableName: String, ruleId: Int, auditID: Int): DataFrame = {
    var t1 =  inputDF.as("df1").join(crossMatrixDF.as("df2"),col("df1.con_row_id1") === col("df2.con_row_id2") && col("df2.failure_rule_id").isNull && col("df1.u_set_id")===col("df2.u_set_id"))
    return t1.select("df1.u_set_id","df1.con_row_id1","df2.con_row_id1")
  }

}