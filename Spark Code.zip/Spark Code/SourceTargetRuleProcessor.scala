package com.telstra.ccm.controller

import com.telstra.audit.service.AuditService
import com.telstra.ccm.controller.RuleProcessor._
import com.telstra.ccm.utils._
import org.apache.spark.sql.{DataFrame, Row, SQLContext, SaveMode}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.hive.HiveContext
import org.apache.commons.lang3.ArrayUtils
import org.slf4j.LoggerFactory

import scala.collection.mutable
import com.telstra.ccm.crl.{PostUnionFilter, QualificationSets, UnionSets}
import org.apache.spark.SparkContext

object SourceTargetRuleProcessor {

  var activeSVArr = Array(401)
  var activeTPArr: Array[Int] = null
  var sourceDF: DataFrame = null
  var resMap = new mutable.HashMap[Int, DataFrame]()
  var sourceValidationRules = new com.telstra.ccm.crl.SourceValidationRules
  var targetPreferenceRules = new com.telstra.ccm.crl.TargetValidationRules
  var preMatchRule = new com.telstra.ccm.crl.PreMatchRules
  var brConDfCount: Long = 0


  def srcInput: Unit = {
    val sc = new SparkContext()
    val sqlContext = new org.apache.spark.sql.hive.HiveContext(sc)
    var unionSet = sqlContext.sql("select * from datalab_dqrdac_dev.union_set where audit_id=140")

    val brCon = sqlContext.sql("select * from datalab_dqrdac_dev.br_con where is_curr=true")
    val brConCust = sqlContext.sql("select distinct cust_row_id,con_row_id,relation_type_cd_rank from datalab_dqrdac_dev.br_con_cust inner join (select row_id from datalab_dqrdac_dev.br_cust where is_curr=true) br_cust on (br_con_cust.cust_row_id=br_cust.row_id) where is_rel_curr = true")
    val sOrgExt = sqlContext.sql("select row_id, ACCNT_TYPE_CD,X_COLLECTIONS_FLG,PR_BL_PER_ID,market_class_cd from datalab_dqrdac_dev.raw_rcrm_s_org_ext")
    val bPay = sqlContext.sql("select Contact_ID, true as Bpay from datalab_dqrdac_dev.pp_extract")
    val raa = sqlContext.sql("select GUID from datalab_dqrdac_dev.guidtoeuid")
    var sContact = sqlContext.sql("select row_id,last_upd,x_last_dvs_verify from datalab_dqrdac_dev.raw_rcrm_s_contact")
    var brConValues = sqlContext.sql("select *, true as flg from datalab_dqrdac_dev.br_con_value ")
    var brCust = sqlContext.sql("select * from datalab_dqrdac_dev.br_cust where is_curr=true")
    var brbill = sqlContext.sql("select * from datalab_dqrdac_dev.br_bill where is_curr=true")


    var tdiExtrnlLnk = sqlContext.sql("select * from datalab_dqrdac.raw_tdi_external_link")
    var tdiUsrContxt = sqlContext.sql("select * from datalab_dqrdac.raw_tdi_user_context")
    val tdiSrc = tdiExtrnlLnk.join(tdiUsrContxt, tdiExtrnlLnk.col("context_id").equalTo(tdiUsrContxt.col("context_id"))).select(col("link_value"), col("guid"))
    val raaList = raa.collect().distinct.map(_ (0)).toSeq
    val euidRule = tdiSrc.filter(col("guid").isin(raaList: _*))
    brConCust.persist()
    var noofCust = unionSet.join(brConCust.where("cust_row_id is not null"), unionSet.col("con_row_id").equalTo(brConCust.col("con_row_id"))).groupBy(brConCust.col("con_row_id")).agg(count("*").as("no_of_customers"))
    val targetOrg = brConCust.join(sOrgExt.where("market_class_cd in ('104','106')"), col("cust_row_id").equalTo(col("row_id"))).select(lit(true).as("is_linked_company_org"), col("con_row_id"))
    val targetNoValidPhone = unionSet.join(brConValues.filter(col("src_field_type").equalTo("email") or col("src_field_type").equalTo("phone")), unionSet.col("con_row_id").equalTo(brConValues.col("row_id"))).groupBy(unionSet.col("con_row_id")).agg(count(col("flg")).as("no_valid_phone_email"))


    var srcFetchCon400403 = unionSet.join(brCon, col("con_row_id").equalTo(col("row_id")), "left_outer").select(unionSet.col("*"), col("is_online"), col("is_inflight_order"), col("is_asset_curr"), col("is_bill_curr"))
    sOrgExt.persist()
    var srcFetchCon401 = srcFetchCon400403.join(sOrgExt.where("ACCNT_TYPE_CD='Billing' and X_COLLECTIONS_FLG='Y'"), srcFetchCon400403.col("con_row_id").equalTo(col("PR_BL_PER_ID")), "left_outer").select(srcFetchCon400403.col("*"), col("X_COLLECTIONS_FLG").cast("boolean"))
    sOrgExt.unpersist()
    val bpayList = bPay.collect().map(_ (0)).toSeq
    var srcFetchCon404 = srcFetchCon401.withColumn("BPay", col("con_row_id").isin(bpayList: _*)).select(srcFetchCon401.col("*"), col("BPay"))

    val euidRuleList = euidRule.select("link_value").distinct().collect().map(_ (0)).toSeq
    var srcFetchCon405 = srcFetchCon404.join(broadcast(euidRule), col("con_row_id").equalTo(col("link_value")), "left_outer").withColumn("euid", when(col("con_row_id").equalTo(col("link_value")), true).otherwise(false)).select(srcFetchCon404.col("*"), col("euid"))

    broadcast(brConValues)
    var targetConVal = srcFetchCon405.join(brConValues.filter(col("src_field_type").equalTo("dl")), srcFetchCon405.col("con_row_id").equalTo(brConValues.col("row_id")), "left_outer").withColumn("valid_dl", col("flg"))
    var conCustTarget = targetConVal.join(noofCust, targetConVal.col("con_row_id").equalTo(noofCust.col("con_row_id")), "left_outer").select(targetConVal.col("*"), col("no_of_customers"))
    sContact.persist()
    val targetScon = conCustTarget.join(sContact, conCustTarget.col("con_row_id").equalTo(sContact.col("row_id")), "left_outer").select(conCustTarget.col("*"), col("last_upd"), col("x_last_dvs_verify"))
    sContact.unpersist()
    val target1 = targetScon.join(targetOrg, targetScon.col("con_row_id").equalTo(targetOrg.col("con_row_id")), "left_outer").select(targetScon.col("*"), col("is_linked_company_org")).distinct

    val srcTgtInpt = target1.join(targetNoValidPhone, target1.col("con_row_id").equalTo(targetNoValidPhone.col("con_row_id")), "left_outer").select(target1.col("*"), col("no_valid_phone_email"))

    //val currentCustList = brCust.select("row_id").intersect(brConCust.select("cust_row_id")).collect().map(_ (0)).toSeq
    var srcTgtCustInpt = srcTgtInpt.join(brConCust, srcTgtInpt.col("con_row_id") === brConCust.col("con_row_id"), "left_outer").select(srcTgtInpt.col("*"), brConCust.col("cust_row_id"), brConCust.col("relation_type_cd_rank"))
    srcTgtCustInpt.persist()
    val crossMatrix = srcTgtCustInpt.alias("df1").select(srcTgtCustInpt.columns.map { c => srcTgtCustInpt.col(c).as(c + "1") }: _*).join(srcTgtCustInpt.alias("df2").select(srcTgtCustInpt.columns.map { c => srcTgtCustInpt.col(c).as(c + "2") }: _*),
      (col("u_set_id1") === (col("u_set_id2")) && col("con_row_id1").notEqual(col("con_row_id2"))))
    crossMatrix.write.mode(SaveMode.Overwrite).format("ORC").saveAsTable("datalab_dqrdac_dev.valid_src")
    srcTgtCustInpt.unpersist()
    //    sOrgExt.rdd.filter(x=>x(0)=="Billing" && x(1)=='Y').collect().distinct.map(_.getString(2)).toSeq
    //    // .join(raa, tdiSrc.col("guid").equalTo(raa.col("GUID"))).select(col("link_value"))
    //    // /val euidRule = tdiSrc.join(raa, tdiSrc.col("guid").equalTo(raa.col("GUID"))).select(col("link_value"))
    //
    //
    //
    //    val currentCust = brConCust.filter(col("cust_row_id").isin(custList  : _*)).select(brConCust.col("cust_row_id"), brConCust.col("con_row_id"), col("relation_type_cd_rank"))
    //   // val currentCust = brConCust.join(brCust, brConCust.col("cust_row_id").equalTo(brCust.col("row_id"))).select(brConCust.col("cust_row_id"), brConCust.col("con_row_id"), col("relation_type_cd_rank"))
    //    var conCustDF = unionSet.join(currentCust, unionSet.col("con_row_id") === currentCust.col("con_row_id"), "left_outer").select(unionSet.col("u_set_id"), unionSet.col("con_row_id"), currentCust.col("cust_row_id"), col("relation_type_cd_rank"))
    //    var srcFetchCon400403 = conCustDF.join(brCon, col("con_row_id").equalTo(col("row_id")), "left_outer").select(conCustDF.col("*"), col("is_online"), col("is_inflight_order"))
    //    var srcFetchCon401 = srcFetchCon400403.join(sOrgExt.where("ACCNT_TYPE_CD='Billing' and X_COLLECTIONS_FLG='Y'"), srcFetchCon400403.col("con_row_id").equalTo(col("PR_BL_PER_ID")), "left_outer").select(srcFetchCon400403.col("*"), col("X_COLLECTIONS_FLG").cast("boolean"))
    //
    //
    //    var srcFetchCon404 = srcFetchCon401.join(bPay, srcFetchCon401.col("con_row_id").equalTo(col("Contact_ID")), "left_outer").select(srcFetchCon401.col("*"), col("BPay"))
    //     // .withColumn("BPay", when(col("con_row_id").equalTo(col("Contact_ID")), true).otherwise(false))
    //    var srcFetchCon405 = srcFetchCon404.join(broadcast(euidRule), col("con_row_id").equalTo(col("link_value")), "left_outer").withColumn("euid", when(col("con_row_id").equalTo(col("link_value")), true).otherwise(false)).select(srcFetchCon404.col("*"), col("euid"))
    //
    //    srcFetchCon405.persist()


  }

  def processSVRule(sqlContext: HiveContext, appId: String, sourceSystem: String, tableName: String, configFile: String, ccmDB: String): Unit = {
    for (ruleId <- activeSVArr) {
      //        methodName = AppConstants.SourceValidationRules + ruleId
      var methodName = "sourcevalidationrules400"
      //methodName = "sourcevalidationrules401"
      var method = sourceValidationRules.getClass.getDeclaredMethod(methodName, classOf[DataFrame], classOf[HiveContext], classOf[String], classOf[String], classOf[String], classOf[Int], classOf[Int])
      //   var ruleResult = method.invoke(sourceValidationRules, sourceDF, sqlContext, appId, sourceSystem, tableName, ruleId, auditID).asInstanceOf[DataFrame]
      //sourcevalidationrules400(inputDF, sqlContext: HiveContext, null, "", "", new Integer(1), new Integer(123) ).asInstanceOf[DataFrame]


      var ruleResult = method.invoke(sourceValidationRules, sourceDF, null, "", "", "", new Integer(ruleId), new Integer(123)).asInstanceOf[DataFrame]
      sourceDF = ruleResult
    }
    sourceDF.write.format("orc").mode(SaveMode.Overwrite).saveAsTable("datalab_dqrdac_dev.source_validation_output")
  }

  def processTPRule(sqlContext: HiveContext, appId: String, sourceSystem: String, tableName: String, configFile: String, ccmDB: String): Unit = {

    var targetDF = sqlContext.sql("select * from datalab_dqrdac_dev.source_validation_output")

    for (ruleId <- activeTPArr) {
      methodName = AppConstants.TargetPreferenceRules + ruleId
      var method = targetPreferenceRules.getClass.getDeclaredMethod(methodName, classOf[DataFrame], classOf[HiveContext], classOf[String], classOf[String], classOf[String], classOf[Int], classOf[Int])
      var ruleResult = method.invoke(targetPreferenceRules, sourceDF, sqlContext, appId, sourceSystem, tableName, ruleId, auditID).asInstanceOf[DataFrame]
      )
      sourceDF = ruleResult
    }
    sourceDF.write.format("orc").saveAsTable("datalab_dqrdac_dev.source_validation_output")
  }

}
