insert into Insights.MAP_UNIFIED_CASH_FLOW_LEG select * from Foundation.FOND_MAP_UNIFIED_CASH_FLOW_LEG

insert into Insights.INSURANCE_CASHFLOW select * from Foundation.FOND_INSURANCE_CASHFLOW

insert into [Insights].[INSURANCE_RISK_DRIVER] select *  from Foundation.FOND_INSURANCE_RISK_DRIVER

insert into Insights.INSURANCE_CONTRACT_GROUP_PVCF select * from Foundation.FOND_INSURANCE_CONTRACT_GROUP_PVCF

drop table Foundation.temp3

---

truncate table Staging.STAG_PROPHET_RPT_WITH_VARSET
truncate table Staging.STAG_PROPHET_RPT_STOMAS
truncate table Foundation.FOND_EXPECTED_CASHFLOW
truncate table Foundation.FOND_CSM_GROUP_ID
truncate table Staging.STAG_CSM_ALS_STOCH
truncate table Staging.STAG_CSM_CCL_STOCH
Truncate table Foundation.FOND_MAPPINGTOSAS
Truncate table Foundation.FOND_MAP_UNIFIED_CASH_FLOW_LEG
Truncate table Foundation.FOND_PROPHET_RUN_MAPPING
truncate table Foundation.FOND_PROPHET_RPT_CE_RUN
truncate table Foundation.FOND_PROPHET_RPT_PRODUCT_LEVEL
truncate table Foundation.FOND_MANUALADJUSTMENT
truncate table Foundation.FOND_UNMODELLEDITEM

truncate table Insights.INSURANCE_CASHFLOW
truncate table Insights.INSURANCE_RISK_DRIVER
truncate table Insights.INSURANCE_CONTRACT_GROUP_PVCF
truncate table 
Insights.MAP_UNIFIED_CASH_FLOW_LEG



