select a.*,b.IFRS_ACQ_EXPN_PAID_E as IFRS_ACQ_EXPN_PAID_E_S
into Foundation.FOND_CSM_GROUP_ID_TEMP1 from Foundation.FOND_CSM_GROUP_ID_TEMP a left join [Staging].[STAG_PROPHET_RPT_CSMGROUP]
 b on a.CSM_GROUP_ID = b.CSM_GROUP_ID and a.STEP_NO_STOCH = b.STEP_NO_STOCH

select * from Foundation.FOND_EXPECTED_CASHFLOW_TEMP



drop table Foundation.FOND_CSM_GROUP_ID_TEMP1 
select a.*,b.IFRS_PV_CFS_IF as IFRS_PV_CFS_IF_S, b.IFRS_PV_OUTGO_IF as IFRS_PV_OUTGO_IF_S, b.IFRS_ACQ_EXPN_PAID_E as IFRS_ACQ_EXPN_PAID_E_S,
b.IFRS_CLAIMS_EXPNS_INCUR_E,b.IFRS_CLM_EXPNS_INCUR_E,b.IFRS_COV_UNITS_IF,b.IFRS_COV_UNITS_IN_PERIOD as IFRS_COV_UNITS_IN_PERIOD_S,
b.IFRS_CSM_PV_CFS_IF as IFRS_CSM_PV_CFS_IF_S,b.IFRS_CSM_PV_EXP_R,b.IFRS_CSM_PV_PREM_TAX_IF,
b.IFRS_CSM_PV_PREM_TAX_IF_T1,
b.IFRS_CSM_PV_PREM_TAX_NB_INCEPT,
b.IFRS_CSM_PV_VAR_FEE_IF as IFRS_CSM_PV_VAR_FEE_IF_S,
b.IFRS_CSM_PV_VAR_FEE_IF_T1,
b.IFRS_CSM_PV_VAR_FEE_NB_INCEPT,
b.IFRS_CSM_VAR_FEE_E,
b.IFRS_FUT_CFS_IF as IFRS_FUT_CFS_IF_S,
b.IFRS_FV_UNDERLYING as IFRS_FV_UNDERLYING_S,
b.IFRS_INIT_COMM_INCUR_E,
b.IFRS_INIT_EXPNS_INCUR_E,
b.IFRS_INV_COMPONENT_OUTGO_E as IFRS_INV_COMPONENT_OUTGO_E_S,
b.IFRS_PREM_RECEIVED_E as IFRS_PREM_RECEIVED_E_S,
b.IFRS_PREM_RELATED_CFS_PAID_E as IFRS_PREM_RELATED_CFS_PAID_E_S,
b.IFRS_PREM_TAX_E,
b.IFRS_PV_CFS_IF_T1,
b.IFRS_PV_CFS_PREV_DISC_IF as IFRS_PV_CFS_PREV_DISC_IF_S,
b.IFRS_RE_COMM_INCUR_E as RE_COMM_INCUR_E_S,
b.IFRS_RE_EXPNS_INCUR_E as IFRS_RE_EXPNS_INCUR_E_S,
b.IFRS_CSM_VAR_FEE_SH_BORNE_CSM_E as IFRS_CSM_VAR_FEE_SH_BORNE_CSM_E_S,
b.IFRS_CSM_VAR_FEE_SH_BORNE_PL_E as IFRS_CSM_VAR_FEE_SH_BORNE_PL_E_S,
b.IFRS_CSM_VAR_FEE_UI_E as IFRS_CSM_VAR_FEE_UI_E_S,
b.IFRS_DISC_INDIRECT_EXP_MAP,
b.IFRS_DISC_RI_PREM_TAXA,
b.IFRS_INS_CLAIMS_INCUR_E as IFRS_INS_CLAIMS_INCUR_E_S,
b.IFRS_SURR_CLAIMS_INCUR_E as IFRS_SURR_CLAIMS_INCUR_E_S
into Foundation.FOND_CSM_GROUP_ID_TEMP1 
from Foundation.FOND_CSM_GROUP_ID_TEMP a left join [Staging].[STAG_PROPHET_RPT_CSMGROUP]
 b on a.CSM_GROUP_ID = b.CSM_GROUP_ID and a.STEP_NO_STOCH = b.STEP_NO_STOCH










 --Foundation Layer Tables

 CREATE TABLE [Foundation].[FOND_PROPHET_RPT_WITH_VARSET](
    REPORT_FILENAME         varchar(100) Not Null, -- derived from filename on data lake
    EXTRACTION_DATE         Date null, -- temporarily set to sysdate 
	GRANULARITY_KEY   varchar(100) null,
    VAR_SET                 varchar(10) null,
    STEP_NO                 varchar(100) null,
	TO_STEP                 varchar(100) null,
    CSM_GROUP_ID            varchar (50) Null, -- currently no value
    IFRS_PORT_GRP           varchar(100) Null,
    IFRS_CY_GRP             varchar (50) Null,
    IFRS_ONEROUS_GRP        varchar (50) Null,
    ENTITY                  varchar (50) Null, -- currently no value
    COHORT_YEAR             smallint Null, -- currently no value
    ENTRY_MONTH             smallint Null,
    MODEL_POINT             varchar(100) Null,
    POL_NO                  varchar(100) Null,
    PROD_CD                 varchar(100) Null,
    BENEFIT_CODE            varchar(100) Null, -- currently no value
    SPCODE                  varchar(100) Null,
    RUN_NO                  smallint Null, -- will be derived from folder name
    MEASURE_MODEL           varchar(100) Null, -- currently no value
    CURRENCY                smallint Null, -- currently no value
    PRODUCT_NAME            varchar(100) Null, -- currently no value
    VALUATION_DATE          Date Null, -- currently no value
    
    IFRS_ACQ_EXPN_PAID_E     numeric(20,10) Null,
    IFRS_COV_UNITS_ACCUM_IF  numeric(20,10) Null, -- currently no value
    IFRS_COV_UNITS_IN_PERIOD numeric(20,10) Null,
        
    IFRS_CSM_PV_CFS_IF       numeric(20,10) Null, 
    IFRS_CSM_PV_CFS_IF_1      numeric(20,10) Null,
    IFRS_CSM_PV_CFS_IF_2      numeric(20,10) Null,
    IFRS_CSM_PV_CFS_IF_3      numeric(20,10) Null,
    IFRS_CSM_PV_CFS_IF_4      numeric(20,10) Null,
    
    IFRS_CSM_PV_CFS_IF_E    numeric(20,10) Null, 
    IFRS_CSM_PV_CFS_IF_E_1    numeric(20,10) Null,
    IFRS_CSM_PV_CFS_IF_E_2    numeric(20,10) Null,
    IFRS_CSM_PV_CFS_IF_E_3    numeric(20,10) Null,
    IFRS_CSM_PV_CFS_IF_E_4    numeric(20,10) Null,
    
    IFRS_CSM_PV_OUTGO_IF    numeric(20,10) Null, 
    IFRS_CSM_PV_OUTGO_IF_1    numeric(20,10) Null,
    IFRS_CSM_PV_OUTGO_IF_2    numeric(20,10) Null,
    IFRS_CSM_PV_OUTGO_IF_3    numeric(20,10) Null,
    IFRS_CSM_PV_OUTGO_IF_4    numeric(20,10) Null,
    
    IFRS_CSM_PV_OUTGO_IF_E  numeric(20,10) Null, 
    IFRS_CSM_PV_OUTGO_IF_E_1  numeric(20,10) Null,
    IFRS_CSM_PV_OUTGO_IF_E_2  numeric(20,10) Null,
    IFRS_CSM_PV_OUTGO_IF_E_3  numeric(20,10) Null,
    IFRS_CSM_PV_OUTGO_IF_E_4  numeric(20,10) Null,
    
    IFRS_CSM_PV_VAR_FEE_IF          numeric(20,10) Null,
    IFRS_CSM_PV_VAR_FEE_IF_E        numeric(20,10) Null,
    IFRS_CSM_VAR_FEE_SH_BORNE_CSM_E numeric(20,10) Null,
    IFRS_CSM_VAR_FEE_SH_BORNE_PL_E  numeric(20,10) Null,
    IFRS_CSM_VAR_FEE_UI_E           numeric(20,10) Null,
    IFRS_FUT_CFS_IF                 numeric(20,10) Null,
    IFRS_FUT_CFS_IF_E               numeric(20,10) Null,
    IFRS_FUT_OUTGO_IF               numeric(20,10) Null,
    IFRS_FUT_OUTGO_IF_E             numeric(20,10) Null,
    IFRS_FV_UNDERLYING              numeric(20,10) Null,
    IFRS_FV_UNDERLYING_E            numeric(20,10) Null,
    IFRS_INS_CLAIMS_INCUR_E         numeric(20,10) Null,
    IFRS_INV_COMPONENT_OUTGO_E      numeric(20,10) Null,
    IFRS_OTHER_INCOME_RECEIVED_E    numeric(20,10) Null,
    IFRS_PREM_RECEIVED_E            numeric(20,10) Null,
    IFRS_PREM_RECEIVED_CUR_E        numeric(20,10) Null,  -- currently no value
    IFRS_PREM_RELATED_CFS_PAID_E    numeric(20,10) Null,
    IFRS_PREM_RELATED_INFLOW_E      numeric(20,10) Null,  -- currently no value
    IFRS_PREM_RELATED_OUTFLOW_E     numeric(20,10) Null,  -- currently no value
    IFRS_PV_ACQ_EXPN_IF             numeric(20,10) Null,  -- currently no value
    IFRS_PV_CFS_IF                  numeric(20,10) Null,
    IFRS_PV_CFS_IF_E                numeric(20,10) Null,
    IFRS_PV_CFS_PREV_DISC_IF        numeric(20,10) Null,
    IFRS_PV_CLAIMS_EXPN_EX_INV_IF   numeric(20,10) Null,  -- currently no value
    IFRS_PV_COV_UNITS_IF            numeric(20,10) Null,
    IFRS_PV_INV_COMPONENT_IF        numeric(20,10) Null,  -- currently no value
    IFRS_PV_OUTGO_IF                numeric(20,10) Null,
    IFRS_PV_OUTGO_IF_E              numeric(20,10) Null,
    IFRS_RE_COMM_INCUR_E            numeric(20,10) Null,
    IFRS_RE_EXPNS_INCUR_E           numeric(20,10) Null,
    IFRS_SURR_CLAIMS_INCUR_E        numeric(20,10) Null,
	[IFRS_PV_COV_UNITS_PROJ_IF_1_0] [numeric](20, 10) NULL,
	[IFRS_PV_COV_UNITS_PROJ_IF_2_0] [numeric](20, 10) NULL,
	[IFRS_PV_COV_UNITS_PROJ_IF_3_0] [numeric](20, 10) NULL,
	[IFRS_PV_COV_UNITS_PROJ_IF_4_0] [numeric](20, 10) NULL,
	[IFRS_PV_COV_UNITS_PROJ_IF_1_1] [numeric](20, 10) NULL,
	[IFRS_PV_COV_UNITS_PROJ_IF_2_1] [numeric](20, 10) NULL,
	[IFRS_PV_COV_UNITS_PROJ_IF_3_1] [numeric](20, 10) NULL,
	[IFRS_PV_COV_UNITS_PROJ_IF_4_1] [numeric](20, 10) NULL,
	[IFRS_PV_COV_UNITS_PROJ_IF_1_2] [numeric](20, 10) NULL,
	[IFRS_PV_COV_UNITS_PROJ_IF_2_2] [numeric](20, 10) NULL,
	[IFRS_PV_COV_UNITS_PROJ_IF_3_2] [numeric](20, 10) NULL,
	[IFRS_PV_COV_UNITS_PROJ_IF_4_2] [numeric](20, 10) NULL,
	[IFRS_PV_COV_UNITS_PROJ_IF_1_3] [numeric](20, 10) NULL,
	[IFRS_PV_COV_UNITS_PROJ_IF_2_3] [numeric](20, 10) NULL,
	[IFRS_PV_COV_UNITS_PROJ_IF_3_3] [numeric](20, 10) NULL,
	[IFRS_PV_COV_UNITS_PROJ_IF_4_3] [numeric](20, 10) NULL,
	[IFRS_PV_COV_UNITS_PROJ_IF_1_4] [numeric](20, 10) NULL,
	[IFRS_PV_COV_UNITS_PROJ_IF_2_4] [numeric](20, 10) NULL,
	[IFRS_PV_COV_UNITS_PROJ_IF_3_4] [numeric](20, 10) NULL,
	[IFRS_PV_COV_UNITS_PROJ_IF_4_4] [numeric](20, 10) NULL,
	[IFRS_PV_COV_UNITS_PROJ_IF_1_5] [numeric](20, 10) NULL,
	[IFRS_PV_COV_UNITS_PROJ_IF_2_5] [numeric](20, 10) NULL,
	[IFRS_PV_COV_UNITS_PROJ_IF_3_5] [numeric](20, 10) NULL,
	[IFRS_PV_COV_UNITS_PROJ_IF_4_5] [numeric](20, 10) NULL,
	[IFRS_PV_COV_UNITS_PROJ_IF_1_6] [numeric](20, 10) NULL,
	[IFRS_PV_COV_UNITS_PROJ_IF_2_6] [numeric](20, 10) NULL,
	[IFRS_PV_COV_UNITS_PROJ_IF_3_6] [numeric](20, 10) NULL,
	[IFRS_PV_COV_UNITS_PROJ_IF_4_6] [numeric](20, 10) NULL,
	[IFRS_PV_COV_UNITS_PROJ_IF_1_7] [numeric](20, 10) NULL,
	[IFRS_PV_COV_UNITS_PROJ_IF_2_7] [numeric](20, 10) NULL,
	[IFRS_PV_COV_UNITS_PROJ_IF_3_7] [numeric](20, 10) NULL,
	[IFRS_PV_COV_UNITS_PROJ_IF_4_7] [numeric](20, 10) NULL, -- there are 4 x 8 fields, how should this be named?  -- currently no value
	[IFRS_TVOG_DRIVER] [numeric](20, 10) NULL,
	[IFRS_COV_UNITS_WEIGHT] [numeric](20, 10) NULL
);


 CREATE TABLE [Foundation].[FOND_PROPHET_RPT_PRODUCT_LEVEL]
(
	RUN_NO [smallint] NULL,PRODUCT_NAME [varchar](50) NULL,BASE_STOCH_BEL [numeric](20, 10) NULL,
BASE_DET_BEL [numeric](20, 10) NULL,BASE_DET_PV_DRIVER [numeric](20, 10) NULL,PAD_STOCH_BEL [numeric](20, 10) NULL,
PAD_DET_BEL [numeric](20, 10) NULL,BASE_STOCH_BEL_E [numeric](20, 10) NULL,
BASE_DET_BEL_E [numeric](20, 10) NULL,
BASE_DET_PV_DRIVER_E [numeric](20, 10) NULL,
PAD_STOCH_BEL_E [numeric](20, 10) NULL,
PAD_DET_BEL_E [numeric](20, 10) NULL,
	[STEP_NO] [varchar](100) NULL,
	[VAR_SET] [varchar](100) NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)