CREATE TABLE [STAG_HKILT].[STAG_RATES_DataSeries]
(
    [DataSeries_Id] numeric(20,0),
    [name] nvarchar(255),
	[BATCH_RUN_ID] [varchar](100) NULL,
	[JOB_RUN_ID] [varchar](100) NULL,
    [EFF_FROM_DT] [date] NULL,
    [EFF_TO_DT] [date] NULL,
    [CURR_IND] [varchar](1) NULL
);

CREATE TABLE [STAG_HKILT].[STAG_RATES_DataSeries_DynamicProperties]
(
    [DynamicProperties_Id] numeric(20,0),
    [DataSeries_Id] numeric(20,0),
	[BATCH_RUN_ID] [varchar](100) NULL,
	[JOB_RUN_ID] [varchar](100) NULL,
    [EFF_FROM_DT] [date] NULL,
    [EFF_TO_DT] [date] NULL,
    [CURR_IND] [varchar](1) NULL
);

CREATE TABLE [STAG_HKILT].[STAG_RATES_DataSeries_DynamicProperties_Property]
(
    [name] nvarchar(255),
    [type] nvarchar(255),
    [text] nvarchar(255),
    [DynamicProperties_Id] numeric(20,0),
	[BATCH_RUN_ID] [varchar](100) NULL,
	[JOB_RUN_ID] [varchar](100) NULL,
    [EFF_FROM_DT] [date] NULL,
    [EFF_TO_DT] [date] NULL,
    [CURR_IND] [varchar](1) NULL
);

CREATE TABLE [STAG_HKILT].[STAG_RATES_DataSeries_Dates]
(
    [Dates_Id] numeric(20,0),
    [DataSeries_Id] numeric(20,0),
	[BATCH_RUN_ID] [varchar](100) NULL,
	[JOB_RUN_ID] [varchar](100) NULL,
    [EFF_FROM_DT] [date] NULL,
    [EFF_TO_DT] [date] NULL,
    [CURR_IND] [varchar](1) NULL
);

CREATE TABLE [STAG_HKILT].[STAG_RATES_DataSeries_Dates_Date]
(
    [effectiveDate] nvarchar(255),
    [text] nvarchar(255),
    [Dates_Id] numeric(20,0),
	[BATCH_RUN_ID] [varchar](100) NULL,
	[JOB_RUN_ID] [varchar](100) NULL,
    [EFF_FROM_DT] [date] NULL,
    [EFF_TO_DT] [date] NULL,
    [CURR_IND] [varchar](1) NULL
);

CREATE TABLE [STAG_HKILT].[STAG_RATES_DataSeries_Axis]
(
    [Axis_Id] numeric(20,0),
    [name] nvarchar(255),
    [value] nvarchar(255),
    [DataSeries_Id] numeric(20,0),
	[BATCH_RUN_ID] [varchar](100) NULL,
	[JOB_RUN_ID] [varchar](100) NULL,
    [EFF_FROM_DT] [date] NULL,
    [EFF_TO_DT] [date] NULL,
    [CURR_IND] [varchar](1) NULL
);

CREATE TABLE [STAG_HKILT].[STAG_RATES_DataSeries_Axis_Values]
(
    [V] decimal(28,10),
    [Axis_Id] numeric(20,0),
	[BATCH_RUN_ID] [varchar](100) NULL,
	[JOB_RUN_ID] [varchar](100) NULL,
    [EFF_FROM_DT] [date] NULL,
    [EFF_TO_DT] [date] NULL,
    [CURR_IND] [varchar](1) NULL
);

CREATE TABLE [STAG_HKILT].[STAG_RATES_DataSeries_Values]
(
    [V] decimal(28,10),
    [DataSeries_Id] numeric(20,0),
	[BATCH_RUN_ID] [varchar](100) NULL,
	[JOB_RUN_ID] [varchar](100) NULL,
    [EFF_FROM_DT] [date] NULL,
    [EFF_TO_DT] [date] NULL,
    [CURR_IND] [varchar](1) NULL
);