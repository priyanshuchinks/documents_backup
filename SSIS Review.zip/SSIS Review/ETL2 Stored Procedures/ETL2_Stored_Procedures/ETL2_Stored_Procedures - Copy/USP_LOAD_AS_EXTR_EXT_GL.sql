IF OBJECT_ID('[FOND_HKILT].[USP_LOAD_AS_EXTR_EXT_GL]', 'P') IS NOT NULL
    DROP PROCEDURE [FOND_HKILT].[USP_LOAD_AS_EXTR_EXT_GL]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
Create PROC [FOND_HKILT].[USP_LOAD_AS_EXTR_EXT_GL] AS 
begin

	truncate table [FOND_HKILT].[FOND_PHKL_AS_ROLLFORWARD_GL_TEMP]
	insert into [FOND_HKILT].[FOND_PHKL_AS_ROLLFORWARD_GL_TEMP]
	(BUSINESS,
	GL_PERIOD,
	POLICY_NUMBER,
	PRODUCT_CODE,
	BENEFIT_CODE,
	SOURCE_CODE,
	POLICY_CURRENCY,
	AMOUNT_CCY,
	SUMOFAMOUNT_HKD,
	SUN_CODE,
	T0,
	T1 ,
	T2,
	T3,
	T4 ,
	JOURNAL,
	ACCT_CD
	)
	select PAS_NAME,
	ACCOUNTING_PERIOD,
	POLICY_NUMBER,
	PRODUCT_CODE,
	BENEFIT_CODE,
	SOURCE_PARM_1,
	ORIGINAL_CURRENCY,
	AMOUNT_ORG_CCY,
	AMOUNT_RPT_CCY,
	NEW_COA,
	T0,
	T1,
	T2,
	T3,
	T4,
	JOURNAL_CODE,
	SOURCE_PARM_2
	from Foundation.FOND_PAS_ACTUAL_CASHFLOW  --Subject to ETL4 change
	where SOURCE_CODE_BY_SYS like '%ORIGINAL%'
	and ENTITY_ID='PHKL'
		
    declare @sql_command1 char(255);
    declare @sql_command2 char(255);
    declare @sql_command3 char(255);
    declare @sql_command4 char(255);
    declare @sql_command5 char(255);
    declare @sql_command6 char(1500);  
    declare @sql_command7 char(255);    
    declare @sql_final char(3000);
    
    declare @TRANSACTION_TYPE varchar(40);
    declare @PAR_TYPE varchar(40);
    declare @SUN_CODE varchar(10);
    declare @T0 varchar(7);
    declare @T2 varchar(7);
    declare @SOURCE_CODE varchar(10);
    declare @SUN_CODE_EXCLUSION varchar(100);
    declare @SOURCE_CODE_EXCLUSION varchar(100);

	declare @SUNEXCpos INT;
	declare @SUNEXClen INT;
	declare @SUNEXCval varchar(10);
    
    
    declare @tmp_var_cnt integer, 
            @i integer = 1; 

	
	IF OBJECT_ID('tempdb..#TMP_FOND_PHKL_ETL2_GL_MAPPING') IS NOT NULL
	DROP TABLE #TMP_FOND_PHKL_ETL2_GL_MAPPING;

    CREATE TABLE #TMP_FOND_PHKL_ETL2_GL_MAPPING
    WITH
    (
        DISTRIBUTION = ROUND_ROBIN
    )
    AS
    select ROW_NUMBER() OVER(ORDER BY (SELECT NULL)) AS sequence, [FOND_HKILT].[FOND_PHKL_AS_GL_MAPPING].* 
    from [FOND_HKILT].[FOND_PHKL_AS_GL_MAPPING] ;

    set @tmp_var_cnt = (SELECT COUNT(*) FROM #TMP_FOND_PHKL_ETL2_GL_MAPPING);
    set @i = 1;
    WHILE   @i <= @tmp_var_cnt
    BEGIN
        SELECT 
            @TRANSACTION_TYPE = TRANSACTION_TYPE,
            @PAR_TYPE = PAR_TYPE,
            @SUN_CODE = SUN_CODE,
            @T0 = T0,
            @T2 = T2,
            @SOURCE_CODE = SOURCE_CODE,
            @SUN_CODE_EXCLUSION = TRIM(SUN_CODE_EXCLUSION),
            @SOURCE_CODE_EXCLUSION = TRIM(SOURCE_CODE_EXCLUSION)
        FROM #TMP_FOND_PHKL_ETL2_GL_MAPPING 
        where sequence=@i;

        SET @sql_command1 = 'update [FOND_HKILT].[FOND_PHKL_AS_ROLLFORWARD_GL_TEMP] SET TRANSACTION_TYPE='''+@TRANSACTION_TYPE+''' , PAR_TYPE='''+@PAR_TYPE+''' ';
        SET @sql_command2 = ' where SUN_CODE like  REPLACE('''+@SUN_CODE +''', ''*'', ''%'') ';
        SET @sql_command3 = ' and T0 like  REPLACE('''+@T0 +''' , ''*'', ''%'') ';

        if @T2 = '*'
            SET @sql_command4 =' ';
        else
            SET @sql_command4 = ' and T2 like  REPLACE('''+@T2 +''', ''*'', ''%'') ';

        if @SOURCE_CODE = '*'
            SET @sql_command5 =' ';
        else
            SET @sql_command5 = ' and CHARINDEX([FOND_HKILT].[FOND_PHKL_AS_ROLLFORWARD_GL_TEMP].SOURCE_CODE , '''+@SOURCE_CODE+''' ) >0 ';
            
        if @SUN_CODE_EXCLUSION is null
            SET @sql_command6 =' ';
        else
			begin
				SET @SUNEXCpos=0
				SET @SUNEXClen=0
				SET @sql_command6 =' ';
				WHILE CHARINDEX(';',@SUN_CODE_EXCLUSION,@SUNEXCpos+1)>0
				BEGIN
					SET @SUNEXClen= CHARINDEX(';',@SUN_CODE_EXCLUSION,@SUNEXCpos+1)-@SUNEXCpos
					SET @SUNEXCval= SUBSTRING(@SUN_CODE_EXCLUSION,@SUNEXCpos,@SUNEXClen)
					SET @SUNEXCpos= CHARINDEX(';',@SUN_CODE_EXCLUSION,@SUNEXCpos+@SUNEXClen)+1
					SET @sql_command6 = RTRIM(@sql_command6)+' and [FOND_HKILT].[FOND_PHKL_AS_ROLLFORWARD_GL_TEMP].SUN_CODE NOT LIKE REPLACE('''+@SUNEXCval+''', ''*'', ''%'') ';

				END
				if (@SUNEXCpos =0)
					SET @sql_command6 = RTRIM(@sql_command6)+' and [FOND_HKILT].[FOND_PHKL_AS_ROLLFORWARD_GL_TEMP].SUN_CODE NOT LIKE REPLACE('''+@SUN_CODE_EXCLUSION+''', ''*'', ''%'') ';
				else
				begin
					SET @SUNEXClen= LEN(@SUN_CODE_EXCLUSION)-(@SUNEXCpos-1)
					SET @SUNEXCval= SUBSTRING(@SUN_CODE_EXCLUSION,@SUNEXCpos,@SUNEXClen)
					SET @sql_command6 =RTRIM(@sql_command6)+' and [FOND_HKILT].[FOND_PHKL_AS_ROLLFORWARD_GL_TEMP].SUN_CODE NOT LIKE REPLACE('''+@SUNEXCval+''', ''*'', ''%'') ';
				end
			end
         
        if @SOURCE_CODE_EXCLUSION is null
            SET @sql_command7 =' ';
        else
            SET @sql_command7 = ' and CHARINDEX([FOND_HKILT].[FOND_PHKL_AS_ROLLFORWARD_GL_TEMP].SOURCE_CODE , '''+@SOURCE_CODE_EXCLUSION+''' ) <= 0 ';
		print @sql_command7;   
        SET @sql_final=RTRIM(@sql_command1) +RTRIM(@sql_command2) +RTRIM(@sql_command3) +RTRIM(@sql_command4) +RTRIM(@sql_command5) + RTRIM(@sql_command6) + RTRIM(@sql_command7);       
        print @sql_final;
        
        EXECUTE (@sql_final);
		set @i = @i + 1;
    END

    DROP table #TMP_FOND_PHKL_ETL2_GL_MAPPING;

	TRUNCATE TABLE [FOND_HKILT].[FOND_PHKL_AS_ROLL_FORWARD_GL] 	
	insert into [FOND_HKILT].[FOND_PHKL_AS_ROLL_FORWARD_GL]
	select * from [FOND_HKILT].[FOND_PHKL_AS_ROLLFORWARD_GL_TEMP]
	where TRANSACTION_TYPE is not null

end
