[Express2].[dbo].[tblBookingParty] -- has boooking id and EMS party Id
[Express2].[dbo].[tblInvoiceParty] -- has invoice number and EMS party id
[Express2].[dbo].[tblParty] -- has Sbu and partyid