[DescartesMgmt].[dbo].[tblDescartesLoadStops] -- has location number , city
[DescartesMgmt].[dbo].tblDescartesDocLoadPlanStops -- has location number, adresss and city