CREATE EXTERNAL TABLE `conformed_otm_global.con_customer`(
Location string, 
 Location_ID string,
 Country string,
 City string,
 State string,
 Postal string)
PARTITIONED BY (
  `snapshot_year` string,
  `snapshot_month` string,
  `snapshot_date` string,
  `source_system_id` int)
ROW FORMAT DELIMITED
  FIELDS TERMINATED BY '\u0001'
STORED AS ORC
LOCATION
  'adl://ppgdadatalakedev.azuredatalakestore.net/data/intake/conformed_otm_comex/gsv/con_customer';