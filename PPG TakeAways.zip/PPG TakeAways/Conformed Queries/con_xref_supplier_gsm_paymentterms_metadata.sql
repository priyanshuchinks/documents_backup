insert into [dbo].[job_metadata] values (301,'M_GSV_con_xref_supplier_gsm_paymentterms','to load con_xref_supplier_gsm_paymentterms ',null,null,null,'curated GSV',current_timestamp,current_timestamp,'manual','manual');

insert into [dbo].[job_metadata] values (302,'J_GSV_con_xref_supplier_gsm_paymentterms','to load con_xref_supplier_gsm_paymentterms',null,null,null,'curated GSV',current_timestamp,current_timestamp,'manual','manual');




INSERT INTO dbo.OBJ_METADATA VALUES (1011,203,'con_xref_supplier_gsm_paymentterms',0,null,0,'NA',
(select obj_id from dbo.OBJ_METADATA where obj_name ='xref_supplier_gsm_paymentterms')

,NULL,NULL,'Y',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'GSV_curated','GSV_curated');


con_xref_supplier_gsm_paymentterms
con_xref_supplier_gsm_paymentterms